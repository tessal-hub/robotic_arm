#ifndef KINEMATICS_H
#define KINEMATICS_H

namespace kin {

// Đơn vị: mm, độ. Nguồn chân lý: docs/ARM_GEOMETRY.md (Modified DH - Craig).
struct Pose {
    float x{0};
    float y{0};
    float z{0};
};

struct JointAngles {
    float j[6]{0, 0, 0, 0, 0, 0}; // góc encoder (độ)
};

struct FkResult {
    Pose tcp;
    Pose wristCenter;
};

// DH constants (bản sao của config.h nhưng thuần C++ để test trên host)
constexpr float D1 = 139.0f;
constexpr float A2 = 138.0f;
constexpr float A3 = 88.0f;
constexpr float D4 = 125.0f;
constexpr float D6 = 55.0f;
constexpr float D_TOOL = 30.0f;
constexpr float D_TOOL_EFFECTIVE = 85.0f;        // D6 + D_TOOL (55 + 30)
constexpr float L_FORE = 152.8692f;              // sqrt(88^2+125^2)
constexpr float DELTA_WRIST = 54.8545f;           // atan2(125, 88) deg

constexpr float THETA2_OFFSET = -90.0f;
constexpr float THETA5_OFFSET = 0.0f;   // J5: offset = 0, enc=0 là pen-down; ARM_GEOMETRY §4

// Giới hạn mềm khớp khi chọn nghiệm IK (độ, theo encoder home)
constexpr float J1_MIN = -90.0f, J1_MAX = 90.0f;
constexpr float J2_MIN = -90.0f, J2_MAX = 90.0f;
constexpr float J3_MIN = 0.0f,   J3_MAX = 90.0f;
constexpr float J5_MIN = -90.0f, J5_MAX = 90.0f;

// FK: encoder(deg) -> TCP + wrist center. Luôn khả thi.
FkResult forward(const float enc[6]);

/**
 * IK closed-form cho chế độ VẼ (bút hướng thẳng xuống, J4 roll giữ mặt phẳng,
 * J6 = 0). Trả về false nếu ngoài vùng với / vi phạm giới hạn mềm.
 * Chọn nhánh khuỷu thoả J3 ∈ [0,90].
 */
bool ikPenDown(const Pose& target, float outEnc[6]);

} // namespace kin

#endif // KINEMATICS_H
