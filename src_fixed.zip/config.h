#ifndef CONFIG_H
#define CONFIG_H

#include <Arduino.h>

// ==============================================================================
// 1. SYSTEM & FIRMWARE METADATA
// ==============================================================================
#define FW_NAME                                 "NEMA-6AXIS-ARM-CONTROLLER"
#define FW_VERSION                              "2.5.0-PRO"
#define FW_BUILD_DATE                           __DATE__ " " __TIME__

// ==============================================================================
// 2. HARDWARE PINOUT (ESP32-S3 DevKitC-1) — BẢNG CHỐT 2026-08-26
//    Loại trừ: GPIO4 (bootloop), GPIO0/3/45/46 (strapping), GPIO19/20 (USB-OTG),
//              GPIO26-32 (flash nội bộ). Dự phòng trống: GPIO14, 17, 18, 48.
//    KHÔNG có chân EN — mọi driver luôn ở trạng thái enabled.
// ==============================================================================
// Cụm 1: Joint 1 -> Joint 4 (TMC2209, chung Serial1: GPIO 15 RX / GPIO 16 TX)
//         Đảo chiều qua UART (shaft register), KHÔNG dùng chân DIR.
constexpr int8_t RX_PIN_1                       = 16;
constexpr int8_t TX_PIN_1                       = 15;
#define SERIAL_PORT_1                           Serial1

// Cụm 2: Joint 5, 6 dùng A4988 (STEP+DIR, không UART)

constexpr uint32_t TMC_UART_BAUD                = 115200;
constexpr float R_SENSE                         = 0.11f;

// Địa chỉ UART trên bus chung (do jumper MS1/MS2 trên board driver)
constexpr uint8_t UART_ADDR_J1                  = 0b00;
constexpr uint8_t UART_ADDR_J2                  = 0b01;
constexpr uint8_t UART_ADDR_J3                  = 0b10;
constexpr uint8_t UART_ADDR_J4                  = 0b11;

// Sentinel "không có chân" (TMC2209 đảo chiều bằng UART shaft)
constexpr uint8_t PIN_UNSET                     = 255;

// Hardware STEP / DIR Pins for 6 Stepper Motors
constexpr uint8_t STEP_PIN_0                    = 1;   // Motor 0 (Joint 1 - Base Yaw)       TMC2209 addr 0b00
constexpr uint8_t STEP_PIN_1                    = 2;   // Motor 1 (Joint 2 - Shoulder Pitch) TMC2209 addr 0b01
constexpr uint8_t STEP_PIN_2                    = 41;  // Motor 2 (Joint 3 - Elbow Pitch)    TMC2209 addr 0b10
constexpr uint8_t STEP_PIN_3                    = 42;  // Motor 3 (Joint 4 - Wrist Pan)      TMC2209 addr 0b11

constexpr uint8_t STEP_PIN_4                    = 38;  // Motor 4 (Joint 5 - independent revolute) - A4988
constexpr uint8_t DIR_PIN_4                     = 39;

constexpr uint8_t STEP_PIN_5                    = 40;  // Motor 5 (Joint 6 - independent revolute) - A4988
constexpr uint8_t DIR_PIN_5                     = 47;

// MG90 gripper: separate servo supply, common GND; calibrate without a load first.
constexpr uint8_t GRIPPER_SERVO_PIN             = 13;
constexpr uint8_t GRIPPER_PWM_CHANNEL           = 0;
constexpr uint8_t GRIPPER_PWM_BITS              = 14;
constexpr uint32_t GRIPPER_PWM_HZ               = 50;
constexpr uint16_t GRIPPER_MIN_PULSE_US         = 1000;
constexpr uint16_t GRIPPER_MAX_PULSE_US         = 2000;
constexpr float GRIPPER_MIN_DEG                = 0.0f;
constexpr float GRIPPER_MAX_DEG                = 180.0f;
static_assert(GRIPPER_MIN_DEG < GRIPPER_MAX_DEG, "Invalid gripper angle range");
static_assert(GRIPPER_MIN_PULSE_US < GRIPPER_MAX_PULSE_US &&
              GRIPPER_MAX_PULSE_US < 1000000 / GRIPPER_PWM_HZ, "Invalid servo pulses");

constexpr uint8_t NUM_MOTORS                    = 6;
constexpr uint8_t CARTESIAN_AXIS_COUNT          = 5;    // J1..J5; J6 roll không đổi TCP khi vẽ

// Chiều quay logic: +1 nếu step CW ứng với góc khớp tăng dương (hiệu chỉnh lúc lắp).
// J2 và J3: góc dương là hướng vươn ra ngoài.
constexpr int8_t AXIS_STEP_SIGN[NUM_MOTORS]     = { +1, +1, -1, -1, +1, +1 };
// Chiều đo AS5600: +1 nếu raw encoder tăng khi góc khớp tăng dương (đo thực tế).
// J5: encoder cùng chiều chuyển động motor (step CW / góc tăng) → +1 (xác nhận người dùng 2026-09-09).
constexpr int8_t AXIS_ENC_SIGN[NUM_MOTORS]      = { -1, -1, 1, -1, 1, -1 };

// ==============================================================================
// 3. I2C SENSOR BUS (PCA9548A Multiplexer + AS5600 Magnetic Encoders)
// ==============================================================================
constexpr int8_t SDA_PIN                        = 8;
constexpr int8_t SCL_PIN                        = 9;
constexpr uint32_t I2C_FREQUENCY                = 20000;  // 20kHz Low-Speed Standard Mode (chống nhiễu/méo xung tối đa cho cáp dài J5/J6)

constexpr uint8_t PCA_ADDR                      = 0x70;
constexpr uint8_t AS5600_ADDR                   = 0x36;
constexpr uint8_t NUM_SENSORS                   = 6;

// Sensor Task configuration (Core 0, 35ms ~28.5Hz)
// SensorScanTask chạy Core 0 (RF/WiFi core) — WiFi chỉ dùng interrupt sau khi kết nối,
// không chiếm CPU liên tục. Tách biệt hoàn toàn với arm_motion (Core 1).
constexpr uint32_t SENSOR_TASK_PERIOD_MS        = 35;
constexpr uint32_t SENSOR_TASK_STACK_SIZE       = 4096;
constexpr UBaseType_t SENSOR_TASK_PRIORITY      = 4;
constexpr BaseType_t SENSOR_TASK_CORE           = 0;
constexpr uint32_t SENSOR_I2C_MUTEX_TIMEOUT_MS  = 50;

// ==============================================================================
// 4. ENDSTOPS / LIMIT SWITCHES (J1, J2, J3)
// ==============================================================================
constexpr uint8_t ENDSTOP_ACTIVE_STATE          = LOW;    // Pull-up active low

// Endstop pins (nhãn MIN/MAX tương ứng với hướng góc - và +)
constexpr int8_t J1_MIN_PIN                     = 6;
constexpr int8_t J1_MAX_PIN                     = 5;
constexpr int8_t J2_MIN_PIN                     = 7;
constexpr int8_t J2_MAX_PIN                     = 10;
constexpr int8_t J3_MIN_PIN                     = 11;
constexpr int8_t J3_MAX_PIN                     = 12;

constexpr int AXIS_MIN_PINS[NUM_MOTORS] = { J1_MIN_PIN, J2_MIN_PIN, J3_MIN_PIN, -1, -1, -1 };
constexpr int AXIS_MAX_PINS[NUM_MOTORS] = { J1_MAX_PIN, J2_MAX_PIN, J3_MAX_PIN, -1, -1, -1 };

// ==============================================================================
// 5. MOTION & CLOSED-LOOP CONTROL DEFAULTS
// ==============================================================================
// Tỉ số truyền độc lập cho từng khớp J1..J6 (Gear Ratios):
constexpr float GEAR_RATIO_J1                   = 6.0f;   // Joint 1 (Base Yaw) - 6:1
constexpr float GEAR_RATIO_J2                   = 20.0f;  // Joint 2 (Shoulder Pitch) - 20:1
constexpr float GEAR_RATIO_J3                   = 20.0f;  // Joint 3 (Elbow Pitch) - 20:1
constexpr float GEAR_RATIO_J4                   = 4.0f;   // Joint 4 (Wrist Roll) - 4:1
constexpr float GEAR_RATIO_J5                   = 3.0f;   // Joint 5 - 3:1
constexpr float GEAR_RATIO_J6                   = 1.0f;   // Joint 6 - direct drive 1:1

constexpr float DEFAULT_AXIS_GEAR_RATIOS[NUM_MOTORS] = {
    GEAR_RATIO_J1,
    GEAR_RATIO_J2,
    GEAR_RATIO_J3,
    GEAR_RATIO_J4,
    GEAR_RATIO_J5,
    GEAR_RATIO_J6
};

constexpr uint16_t DEFAULT_FULL_STEPS           = 200;    // 1.8 degree stepper (200 steps/rev)
constexpr uint16_t DEFAULT_MICROSTEPS           = 16;     // 1/16 microstepping
constexpr uint16_t DEFAULT_NORMAL_CURRENT       = 800;    // Normal running current (mA)

constexpr uint16_t NORMAL_CURRENT_J1            = 1000;    // Base Yaw (mA)
constexpr uint16_t NORMAL_CURRENT_J2            = 1700;   // Shoulder Pitch (mA) — nâng cánh tay trên
constexpr uint16_t NORMAL_CURRENT_J3            = 1700;   // Elbow Pitch (mA) — nâng khuỷu tay
constexpr uint16_t NORMAL_CURRENT_J4            = 550;    // Wrist Pan (mA) - đủ mô-men vượt ma sát/cáp trong StealthChop
constexpr uint16_t NORMAL_CURRENT_J5            = 0;      // A4988 - VREF cứng
constexpr uint16_t NORMAL_CURRENT_J6            = 0;      // A4988 - VREF cứng

constexpr uint16_t DEFAULT_AXIS_RUN_CURRENTS[NUM_MOTORS] = {
    NORMAL_CURRENT_J1,
    NORMAL_CURRENT_J2,
    NORMAL_CURRENT_J3,
    NORMAL_CURRENT_J4,
    NORMAL_CURRENT_J5,
    NORMAL_CURRENT_J6
};

constexpr uint16_t HOMING_CURRENT_J1            = 1000;    // Base Yaw (mA) — cần traverse full range, ISR endstop bảo vệ chạm
constexpr uint16_t HOMING_CURRENT_J2            = 1000;    // Shoulder Pitch (mA)
constexpr uint16_t HOMING_CURRENT_J3            = 1000;    // Elbow Pitch (mA)
constexpr uint16_t HOMING_CURRENT_J4            = 550;    // Wrist Pan (mA) — đủ mô-men vượt ma sát/cáp trong StealthChop, Back-EMF rõ cho SG4
constexpr uint16_t HOMING_CURRENT_J5            = 0;      // A4988 - VREF cứng
constexpr uint16_t HOMING_CURRENT_J6            = 0;      // A4988 - VREF cứng

constexpr uint16_t DEFAULT_AXIS_HOMING_CURRENTS[NUM_MOTORS] = {
    HOMING_CURRENT_J1,
    HOMING_CURRENT_J2,
    HOMING_CURRENT_J3,
    HOMING_CURRENT_J4,
    HOMING_CURRENT_J5,
    HOMING_CURRENT_J6
};

constexpr uint32_t HOMING_STEP_INTERVAL_J1      = 1100;   // 909 steps/s
constexpr uint32_t HOMING_STEP_INTERVAL_J2      = 1200;   // 833 steps/s; giảm riêng J2 để giữ torque/giảm EMI
constexpr uint32_t HOMING_STEP_INTERVAL_J3      = 900;    // 1111 steps/s
constexpr uint32_t HOMING_STEP_INTERVAL_J4      = 1200;   // 833 steps/s
constexpr uint32_t HOMING_STEP_INTERVAL_J5      = 1500;   // 667 steps/s
constexpr uint32_t HOMING_STEP_INTERVAL_J6      = 1500;   // 667 steps/s

constexpr uint32_t DEFAULT_AXIS_HOMING_SPEEDS[NUM_MOTORS] = {
    HOMING_STEP_INTERVAL_J1,
    HOMING_STEP_INTERVAL_J2,
    HOMING_STEP_INTERVAL_J3,
    HOMING_STEP_INTERVAL_J4,
    HOMING_STEP_INTERVAL_J5,
    HOMING_STEP_INTERVAL_J6
};

constexpr uint8_t DEFAULT_HOLD_SCALE            = 30;     // TMC2209 ihold scale
constexpr uint16_t DEFAULT_STALL_THRESHOLD      = 135;    // StallGuard4 SGTHRS threshold (0..255, độ nhạy cao ngắt nhẹ khi chạm)

// Homing fusion: endstop + StallGuard + encoder + step counting
constexpr float HOME_BACKOFF_DEG                = 2.0f;   // Lùi ra sau khi chạm endstop/stall
constexpr uint16_t STALL_SG_LEVEL               = 30;     // SG_RESULT < 30 khi tải tăng (chặn chạm cứng thực sự, không ngắt nhầm khi chạy tự do)
constexpr uint8_t STALL_CONSECUTIVE_POLLS       = 2;      // Poll liên tiếp xác nhận stall
constexpr uint32_t HOMING_JOINT_TIMEOUT_MS      = 30000;  // Timeout tối đa cho 1 khớp
constexpr uint32_t HOMING_POLL_MS               = 20;     // Chu kỳ giám sát endstop/stall trong FSM (20ms giảm tải UART)

// Homing 2 tốc độ (quét 2 cữ J1..J4): FAST tìm cữ thô, SLOW tiếp cận lại lấy mốc chính xác.
// Glitch ở pha FAST tự hồi phục vì pha SLOW dò lại đúng cữ đó; VERIFY đối chiếu encoder độc lập.
constexpr uint32_t HOMING_SLOW_SCAN_INTERVAL_US = 1800;   // 556 steps/s, vẫn chậm hơn FAST
constexpr uint8_t  HOMING_MAX_ATTEMPTS          = 2;      // Số lần thử tối đa mỗi khớp trước khi hủy chuỗi
constexpr float    HOMING_VERIFY_TOL_BASE_DEG   = 0.5f;   // Verify tại home: dung sai gốc (độ raw encoder)
constexpr float    HOMING_VERIFY_TOL_SPAN_PCT   = 1.0f;   // Verify: + % của nửa span (chịu sai số steps/deg đo được)
constexpr float    HOMING_STALL_WINDOW_MIN_DEG  = 4.0f;   // Cửa sổ step-lag tối thiểu (độ) — phải > 2x ngưỡng dưới
constexpr float    HOMING_STALL_ENC_DELTA_DEG   = 1.0f;   // Encoder dịch < ngưỡng trong cửa sổ => stall (nhạy, dừng ngay khi chạm)
constexpr int32_t  HOMING_STALL_WINDOW_MIN_STEPS = 180;   // Sàn cửa sổ (180 bước ~ 0.36s) — phát hiện kẹt nhanh chóng
// Span encoder tối thiểu sau khi quét đủ 2 cữ: thấp hơn ngưỡng này (motor đã đi hàng trăm
// bước) chứng tỏ encoder đóng băng/đọc lỗi → HỦY khớp, không home ảo.
constexpr float    HOMING_MIN_ENC_SPAN_DEG[NUM_MOTORS] = { 30.0f, 30.0f, 30.0f, 15.0f, 10.0f, 10.0f };
// J4 sensorless hard-stop span integrity floor. Commissioning 2026-09-06 lặp lại
// 679–716 steps (~19–20° theo config), nên giữ sàn 15° để chặn contact kép gần nhau.
constexpr float    HOMING_MIN_MECHANICAL_SPAN_DEG = 15.0f;
// J4 commissioning mới cần quét tới 150° để tìm cữ; vẫn bị chặn bởi timeout 60s.
constexpr float    HOMING_J4_MAX_MECHANICAL_SPAN_DEG = 150.0f;
constexpr float    HOMING_TRIM_MAX_TRAVEL_DEG  = 15.0f;   // Giới hạn hành trình mỗi lần trim VERIFY (chống trim chạy loạn đâm endstop)
constexpr uint8_t  HOMING_BACKOFF_MAX_EXTEND    = 3;      // Số lần nới rộng backoff (2.5°→5°→10°→20°) khi công tắc chưa nhả (hysteresis đòn bẩy)
constexpr uint32_t HOMING_BACKOFF_SETTLE_MS    = 30;     // Settle cơ khí & tiếp điểm sau khi dừng đột ngột từ pha quét (non-blocking)

// Speed & Acceleration Timing (microseconds per step pulse)
constexpr uint32_t DEFAULT_STEP_INTERVAL_US     = 720;    // Target step interval -> 1389 steps/sec
constexpr uint32_t MIN_STEP_INTERVAL_US         = 120;    // Max speed limit -> ~8333 steps/sec
constexpr uint32_t MAX_STEP_INTERVAL_US         = 3500;   // Starting speed interval (~285 steps/sec, max static torque)

// Tốc độ Jog độc lập từng khớp (us/step) — tối ưu mô-men xoắn cao tuyệt đối, không trượt bước:
constexpr uint32_t DEFAULT_AXIS_JOG_SPEEDS[NUM_MOTORS] = {
    720,   // J1 (6:1):  1389 steps/s -> 26.04 deg/s
    1100,  // J2 (20:1): 909 steps/s  -> 5.11 deg/s
    1100,  // J3 (20:1): 909 steps/s  -> 5.11 deg/s
    900,   // J4 (4:1):  1111 steps/s -> 31.25 deg/s
    1500,  // J5 (3:1):  667 steps/s  -> 25.00 deg/s
    1500   // J6 (1:1):  667 steps/s  -> 75.00 deg/s
};

// Drawing (Cartesian trajectory, pen = tool coaxial J6)
constexpr float PEN_LIFT_MM                     = 5.0f;   // Độ nâng bút giữa các nét (Z-raise)
constexpr float DRAW_FEED_MM_S                  = 10.0f;  // Feed mặc định êm hơn; giảm rung tại biên segment
constexpr float DRAW_PLANE_Z_MM                 = 20.0f;  // Mặt phẳng vẽ base-Z duy nhất
constexpr float DRAW_SEGMENT_MM                 = 1.0f;   // Bước rời rạc hóa quỹ đạo
constexpr float DRAW_LINE_SEGMENT_MM            = 2.0f;   // Line thẳng: ít stop/start hơn, circle/square giữ 1 mm
constexpr uint8_t PLANNER_QUEUE_DEPTH           = 24;     // Số segment tối đa trong hàng đợi

// Preset "vẽ nhanh": quét IK trong nửa không gian phía trước để đề xuất các cao độ Z
// có ô vuông liên tục lớn nhất. Tất cả ô được kiểm tra cả lúc chạm giấy và nâng bút.
constexpr float DRAW_PRESET_SAFE_SCALE_MM       = 0.60f; // inset 40% vào ô max để chịu sai số cơ khí
constexpr float DRAW_PRESET_MIN_SQUARE_SIDE_MM  = 40.0f;
constexpr float DRAW_PRESET_MAX_SIZE_MM         = 260.0f;

// Motion Control Task configuration (Core 1, 100Hz)
constexpr uint32_t MOTION_TASK_PERIOD_MS        = 10;
constexpr uint32_t MOTION_TASK_STACK_SIZE       = 5120;
constexpr UBaseType_t MOTION_TASK_PRIORITY      = 3;
constexpr BaseType_t MOTION_TASK_CORE           = 1;

constexpr float DH_D1_MM                        = 139.0f; // J1 -> J2: Chiều cao đế lên vai (Base height)
constexpr float DH_A2_MM                        = 138.0f; // J2 -> J3: Cánh tay trên (Upper arm length)
constexpr float DH_A3_MM                        = 88.0f;  // J3 -> Điểm gập (Elbow longitudinal offset)
constexpr float DH_D4_MM                        = 125.0f; // Forearm bend -> J5 = 16 mm + 109 mm (J4 -> J5)
constexpr float DH_D6_MM                        = 55.0f;  // J5 -> J6
constexpr float DH_D_TOOL_MM                    = 30.0f;  // Bút (tool), gắn đồng trục với J6 (30mm từ J6)
constexpr float DH_TOOL_EFFECTIVE_MM            = 85.0f;  // J5 -> TCP = 55 + 30
constexpr float DH_D6_TOOL_MM                   = DH_TOOL_EFFECTIVE_MM; // Alias tương thích ngược

// Angle Offsets: theta_DH = theta_encoder + OFFSET
constexpr float DH_THETA1_OFFSET_DEG            = 0.0f;
constexpr float DH_THETA2_OFFSET_DEG            = -90.0f; // Khớp vai lệch -90 độ khi encoder = 0
constexpr float DH_THETA3_OFFSET_DEG            = 0.0f;   // Khớp khuỷu thẳng đứng khi encoder = 0
constexpr float DH_THETA4_OFFSET_DEG            = 0.0f;
constexpr float DH_THETA5_OFFSET_DEG            = 0.0f;   // J5: offset = 0 per ARM_GEOMETRY §4; enc=0 → bút thẳng xuống qua cơ học
constexpr float DH_THETA6_OFFSET_DEG            = 0.0f;

// Joint Soft Angle Limits (Degrees relative to Calibrated Home)
constexpr float J1_MIN_LIMIT                    = -90.0f; // 270 deg total stroke
constexpr float J1_MAX_LIMIT                    = +90.0f;
constexpr float J2_MIN_LIMIT                    = -90.0f;  // 180 deg total stroke
constexpr float J2_MAX_LIMIT                    = +90.0f;
// Owner-locked mechanical envelope: J3 home is straight/aligned (MIN + 2.5 deg offset).
// Negative elbow motion past home is not permitted, aligning with kin::J3_MIN/MAX.
constexpr float J3_MIN_LIMIT                    = 0.0f;
constexpr float J3_MAX_LIMIT                    = +90.0f;  // 90 deg total stroke (0..+90)
constexpr float J4_MIN_LIMIT                    = -75.0f;  // 150 deg total stroke
constexpr float J4_MAX_LIMIT                    = +75.0f;
constexpr float J5_MIN_LIMIT                    = -90.0f;
constexpr float J5_MAX_LIMIT                    = +90.0f;
constexpr float J6_MIN_LIMIT                    = -360.0f;
constexpr float J6_MAX_LIMIT                    = +360.0f;

constexpr float DEFAULT_AXIS_LIMIT_MIN[NUM_MOTORS] = {
    J1_MIN_LIMIT, J2_MIN_LIMIT, J3_MIN_LIMIT, J4_MIN_LIMIT, J5_MIN_LIMIT, J6_MIN_LIMIT
};

constexpr float DEFAULT_AXIS_LIMIT_MAX[NUM_MOTORS] = {
    J1_MAX_LIMIT, J2_MAX_LIMIT, J3_MAX_LIMIT, J4_MAX_LIMIT, J5_MAX_LIMIT, J6_MAX_LIMIT
};

constexpr float DEFAULT_AXIS_CALIB_RANGE[NUM_MOTORS] = {
    (J1_MAX_LIMIT - J1_MIN_LIMIT),
    (J2_MAX_LIMIT - J2_MIN_LIMIT),
    (J3_MAX_LIMIT - J3_MIN_LIMIT),
    (J4_MAX_LIMIT - J4_MIN_LIMIT),
    (J5_MAX_LIMIT - J5_MIN_LIMIT),
    (J6_MAX_LIMIT - J6_MIN_LIMIT)
};

// Khóa cứng hoàn toàn cụm cổ tay J4, J5, J6 (true = không cho phép Jog/Home/ShowOff xoay J4..J6, không bù góc)
constexpr bool LOCK_WRIST_J4_J6                 = true;
// Dòng giữ tĩnh (ihold scale 0..31) cho J4 (TMC2209) để khóa cứng cổ tay
constexpr uint8_t WRIST_J4_HOLD_SCALE           = 28;

// ==============================================================================
// 7. NETWORKING & SYSTEM CONFIGURATION
// ==============================================================================
#define DEFAULT_AP_SSID                         "6AXIS-CONTROLLER"
#define DEFAULT_AP_PASS                         "12345678"
#define DEFAULT_MDNS_HOST                       "robot-arm"
constexpr uint16_t WEB_SERVER_PORT              = 80;
constexpr uint32_t WIFI_STA_BOOT_TIMEOUT_MS     = 6000;

#endif // CONFIG_H
