#include "motor.h"
#include "driver/gpio.h"
#include "rtos_guard.h"
#ifdef ARDUINO
#include "safety_manager.h"
#endif

Motor::Motor(HardwareSerial* serial, float rSense, uint8_t uartAddress,
             uint8_t stepPinNum, uint8_t dirPinNum, const char* motorLabel)
    : serialPort(serial),
      uartMutex(nullptr),
      driver(serial ? new TMC2209Stepper(serial, rSense, uartAddress) : nullptr),
      isTMC(serial != nullptr), // Xác định loại driver
      stepPin(stepPinNum),
      dirPin(dirPinNum),
      address(uartAddress),
      label(motorLabel),
      running(false),
      dirCW(true),
      targetSpeedUs(DEFAULT_STEP_INTERVAL_US),
      currentSpeedUs(MAX_STEP_INTERVAL_US),
      startSpeedUs(MAX_STEP_INTERVAL_US),
      targetSteps(0),
      stepsRemaining(0),
      stepCounter(0),
      accelSteps(60),
      decelSteps(60),
      continuousMode(false),
      coordinatedMode(false),
      preparedRun(false),
      currentMa(DEFAULT_NORMAL_CURRENT),
      spreadCycleMode(true),
      microstepsVal(DEFAULT_MICROSTEPS),
      holdScale(DEFAULT_HOLD_SCALE),
      enabled(true),
      uartOk(false),
      driverVersion(0),
      stepTimer(nullptr)
{
    isHighPin = (stepPinNum >= 32);
    if (isHighPin) {
        stepPinMaskLow = 0;
        stepPinMaskHigh = (1UL << (stepPinNum - 32));
    } else {
        stepPinMaskLow = (1UL << stepPinNum);
        stepPinMaskHigh = 0;
    }
}

Motor::~Motor() {
    if (stepTimer != nullptr) {
        esp_timer_stop(stepTimer);
        esp_timer_delete(stepTimer);
        stepTimer = nullptr;
    }
}

inline uint32_t Motor::calculateSCurveInterval(uint32_t currentStep, uint32_t totalSteps,
                                               uint32_t startInterval, uint32_t targetInterval) {
    if (totalSteps == 0 || currentStep >= totalSteps) return targetInterval;
    if (startInterval == targetInterval) return targetInterval;

    const float x = static_cast<float>(currentStep) / static_cast<float>(totalSteps);
    const float s = x * x * (3.0f - 2.0f * x);

    const float vStart = 1000000.0f / static_cast<float>(startInterval);
    const float vTarget = 1000000.0f / static_cast<float>(targetInterval);
    const float vCurrent = vStart + s * (vTarget - vStart);

    if (vCurrent <= 0.0f) return startInterval;
    uint32_t interval = static_cast<uint32_t>(1000000.0f / vCurrent);
    if (interval < MIN_STEP_INTERVAL_US) interval = MIN_STEP_INTERVAL_US;
    return interval;
}

void IRAM_ATTR Motor::onStepTimer(void* arg) {
    Motor* self = static_cast<Motor*>(arg);
    if (!self->running.load(std::memory_order_acquire)) return;

    // Fail-fast emergency stop check (Instantaneous abort <= 20us) — SafetyManager single owner
#ifdef ARDUINO
    if (self->safety_ && self->safety_->isEStop()) {
        if (self->isHighPin) GPIO.out1_w1tc.val = self->stepPinMaskHigh;
        else GPIO.out_w1tc = self->stepPinMaskLow;
        self->running.store(false, std::memory_order_release);
        return;
    }
    // Guard race: stopFromISR() nổ giữa lệnh stepsRemaining.store() và
    // running.store(true) của run()/runContinuous() để lại running==true với
    // stepsRemaining==0 (continuousMode cũng bị ISR reset). Không có guard này,
    // callback rơi qua cả hai nhánh đếm bước nhưng vẫn phát xung + tự re-arm
    // vô hạn trong khi absSteps đóng băng (mô hình vị trí lệch hoàn toàn).
    const bool isCont = self->continuousMode.load(std::memory_order_relaxed);
    uint32_t remaining = self->stepsRemaining.load(std::memory_order_relaxed);
    if (!isCont && (remaining == 0 || remaining == 0xFFFFFFFF)) {
        self->running.store(false, std::memory_order_release);
        return;
    }

    if (self->isHighPin) GPIO.out1_w1ts.val = self->stepPinMaskHigh;
    else GPIO.out_w1ts = self->stepPinMaskLow;
    esp_rom_delay_us(4); // 4us clean pulse width cho A4988 và TMC
    if (self->isHighPin) GPIO.out1_w1tc.val = self->stepPinMaskHigh;
    else GPIO.out_w1tc = self->stepPinMaskLow;
#else
    gpio_set_level(static_cast<gpio_num_t>(self->stepPin), 1);
    esp_rom_delay_us(4); // 4us clean pulse width cho A4988 và TMC
    gpio_set_level(static_cast<gpio_num_t>(self->stepPin), 0);
#endif

    uint32_t nextInterval = self->targetSpeedUs.load(std::memory_order_relaxed);

    if (!isCont && remaining > 0 && remaining != 0xFFFFFFFF) {
        const uint32_t counter = self->stepCounter.fetch_add(1, std::memory_order_relaxed) + 1;
        remaining = self->stepsRemaining.fetch_sub(1, std::memory_order_relaxed) - 1;
        self->absSteps.fetch_add(self->dirCW.load(std::memory_order_relaxed) ? 1 : -1,
                                 std::memory_order_relaxed);

        if (counter < self->accelSteps) {
            nextInterval = calculateSCurveInterval(counter, self->accelSteps, self->startSpeedUs, self->targetSpeedUs.load(std::memory_order_relaxed));
        } else if (self->decelSteps > 0 && remaining <= self->decelSteps) {
            nextInterval = calculateSCurveInterval(remaining, self->decelSteps, self->startSpeedUs, self->targetSpeedUs.load(std::memory_order_relaxed));
        }

        self->currentSpeedUs.store(nextInterval, std::memory_order_relaxed);

        if (remaining == 0) {
            self->running.store(false, std::memory_order_release);
            return;
        }
    } else if (isCont) {
        const uint32_t counter = self->stepCounter.fetch_add(1, std::memory_order_relaxed) + 1;
        self->absSteps.fetch_add(self->dirCW.load(std::memory_order_relaxed) ? 1 : -1,
                                 std::memory_order_relaxed);
        if (counter < self->accelSteps) {
            nextInterval = calculateSCurveInterval(counter, self->accelSteps, self->startSpeedUs, self->targetSpeedUs.load(std::memory_order_relaxed));
        }
        self->currentSpeedUs.store(nextInterval, std::memory_order_relaxed);
    }

    if (nextInterval < MIN_STEP_INTERVAL_US) nextInterval = MIN_STEP_INTERVAL_US;
    if (!self->coordinatedMode.load(std::memory_order_relaxed) &&
        nextInterval > MAX_STEP_INTERVAL_US) {
        nextInterval = MAX_STEP_INTERVAL_US;
    }

    bool estop = false;
#ifdef ARDUINO
    estop = (self->safety_ && self->safety_->isEStop());
#endif
    if (!self->running.load(std::memory_order_acquire) || estop) {
        self->running.store(false, std::memory_order_release);
        return;
    }

    if (esp_timer_start_once(self->stepTimer, nextInterval) != ESP_OK) {
        self->running.store(false, std::memory_order_release);
        self->stepsRemaining.store(0, std::memory_order_relaxed);
    }
}

bool Motor::takeUart(uint32_t timeoutMs) {
    if (!isTMC) return true;
    // A TMC transaction without the shared mutex can corrupt another driver's
    // datagram. Missing startup synchronization therefore fails closed.
    if (uartMutex == nullptr || *uartMutex == nullptr) return false;
    if (timeoutMs == portMAX_DELAY) return xSemaphoreTake(*uartMutex, portMAX_DELAY) == pdTRUE;
    return xSemaphoreTake(*uartMutex, pdMS_TO_TICKS(timeoutMs)) == pdTRUE;
}

void Motor::giveUart() {
    if (isTMC && uartMutex != nullptr && *uartMutex != nullptr) xSemaphoreGive(*uartMutex);
}

void Motor::flushUartRx() {
    if (isTMC && serialPort != nullptr) {
#ifdef ARDUINO
        serialPort->flush();
        esp_rom_delay_us(200);
#endif
        while (serialPort->available()) serialPort->read();
    }
}

bool Motor::testUART() {
    if (!isTMC) return true; // A4988 ko có UART
    if (!takeUart(50)) {
        uartOk = false;
        return false;
    }
    flushUartRx();
    driverVersion = driver->version();
    const bool readError = driver->CRCerror;
    uartOk = (driverVersion == 0x21) && !readError;
    giveUart();
    Serial.printf("[TMC UART READ] %s addr=%u version=0x%02X expected=0x21 readError=%u (timeout/CRC)\n",
                  label, address, driverVersion, readError);
    return uartOk;
}

void Motor::begin(uint16_t initialCurrentMa, uint16_t initialMicrosteps,
                   bool initialSpreadCycle, uint8_t initialHoldScale, uint8_t iholddelay) {
    gpio_reset_pin(static_cast<gpio_num_t>(stepPin));
    pinMode(stepPin, OUTPUT);
    digitalWrite(stepPin, LOW);
    gpio_config_t cfg = {};
    cfg.pin_bit_mask = (1ULL << stepPin);
    cfg.mode = GPIO_MODE_OUTPUT;
    cfg.pull_up_en = GPIO_PULLUP_DISABLE;
    cfg.pull_down_en = GPIO_PULLDOWN_DISABLE;
    cfg.intr_type = GPIO_INTR_DISABLE;
    gpio_config(&cfg);
    gpio_set_level(static_cast<gpio_num_t>(stepPin), 0);
    gpio_set_drive_capability(static_cast<gpio_num_t>(stepPin), GPIO_DRIVE_CAP_3);

    if (dirPin != 255) {
        gpio_reset_pin(static_cast<gpio_num_t>(dirPin));
        pinMode(dirPin, OUTPUT);
        digitalWrite(dirPin, LOW);
        gpio_config_t dirCfg = {};
        dirCfg.pin_bit_mask = (1ULL << dirPin);
        dirCfg.mode = GPIO_MODE_OUTPUT;
        dirCfg.pull_up_en = GPIO_PULLUP_DISABLE;
        dirCfg.pull_down_en = GPIO_PULLDOWN_DISABLE;
        dirCfg.intr_type = GPIO_INTR_DISABLE;
        gpio_config(&dirCfg);
        gpio_set_level(static_cast<gpio_num_t>(dirPin), 0);
        gpio_set_drive_capability(static_cast<gpio_num_t>(dirPin), GPIO_DRIVE_CAP_3);
    }

    if (stepTimer != nullptr) {
        esp_timer_stop(stepTimer);
        esp_timer_delete(stepTimer);
        stepTimer = nullptr;
    }

    const esp_timer_create_args_t timerArgs = {
        .callback = &Motor::onStepTimer,
        .arg = this,
        .dispatch_method = ESP_TIMER_TASK,
        .name = label,
        .skip_unhandled_events = true
    };
    const esp_err_t err = esp_timer_create(&timerArgs, &stepTimer);
    if (err != ESP_OK) {
        Serial.printf("[MOTOR LOI] %s esp_timer_create that bai: %d\n", label, err);
    }

    if (!isTMC) {
        enabled.store(true, std::memory_order_relaxed);
        Serial.printf("  >> [A4988 OK] %s (STEP Pin %d, DIR Pin %d)\n", label, stepPin, dirPin);
        return; // A4988 xong
    }

    if (!takeUart(portMAX_DELAY)) return;
    flushUartRx();

    driver->begin();
    driver->toff(4);
    enabled.store(true, std::memory_order_relaxed);
    driver->pdn_disable(true);
    driver->I_scale_analog(false);
    driver->mstep_reg_select(true);

    currentMa = initialCurrentMa;
    driver->rms_current(currentMa);

    microstepsVal = initialMicrosteps;
    driver->microsteps(microstepsVal);

    spreadCycleMode = initialSpreadCycle;
    driver->en_spreadCycle(spreadCycleMode);
    if (spreadCycleMode) {
        driver->pwm_autoscale(false);
        driver->pwm_autograd(false);
    } else {
        driver->pwm_autoscale(true);
        driver->pwm_autograd(true);
    }

    holdScale = initialHoldScale;
    driver->ihold(holdScale);
    driver->iholddelay(iholddelay);

    if (address == UART_ADDR_J4) {
        // Chỉ J4 sensorless homing mới cần StallGuard4
        driver->TCOOLTHRS(0xFFFFF);
        driver->SGTHRS(DEFAULT_STALL_THRESHOLD);
    }

    // Observe the existing startup write; no extra configuration or motion command.
    flushUartRx();
    const uint8_t ifcntBefore = driver->IFCNT();
    const bool beforeError = driver->CRCerror;
    driver->shaft(false);
#ifdef ARDUINO
    serialPort->flush();
    delay(2);
#endif
    flushUartRx();
    const uint8_t ifcntAfter = driver->IFCNT();
    const bool afterError = driver->CRCerror;

    giveUart();

    Serial.printf("[TMC UART WRITE] %s addr=%u IFCNT=%u->%u delta=%u expected=1 readError=%u/%u (delta valid only if both errors=0)\n",
                  label, address, ifcntBefore, ifcntAfter,
                  static_cast<uint8_t>(ifcntAfter - ifcntBefore), beforeError, afterError);
    testUART();
    if (uartOk) {
        Serial.printf("  >> [TMC2209 OK] %s (Addr %u, STEP Pin %d): UART tot! Ver: 0x%02X\n", label, address, stepPin, driverVersion);
    } else {
        Serial.printf("  >> [TMC2209 LOI] %s (Addr %u, STEP Pin %d): KHONG UART!\n", label, address, stepPin);
    }
}

bool Motor::setDirection(bool cw) {
    if (dirPin != 255) { // A4988 hoặc TMC có chân DIR vật lý
        dirCW.store(cw, std::memory_order_relaxed);
        digitalWrite(dirPin, cw ? HIGH : LOW);
        gpio_set_level(static_cast<gpio_num_t>(dirPin), cw ? 1 : 0);
        return true;
    }

    if (isTMC && dirPin == 255) { // TMC dùng UART đảo chiều
        if (uartOk && dirCW.load(std::memory_order_relaxed) == cw) {
            return true;
        }
        auto lock = makeTimedLock(uartMutex ? *uartMutex : nullptr, 50);
        if (!lock) return false;
        flushUartRx();
#ifndef ESP_PLATFORM
        const bool actual = driver->shaft();
        uartOk = !driver->CRCerror;
        if (!uartOk) return false; // A timeout returns false too: inspect CRCerror.
        if (actual != cw) {
            driver->shaft(cw);
            flushUartRx();
            const bool verified = driver->shaft();
            uartOk = !driver->CRCerror && verified == cw;
            if (!uartOk) return false;
        }
#else
        driver->shaft(cw);
        serialPort->flush();
        delay(2);
        flushUartRx();
        const bool verified = driver->shaft();
        const bool err = driver->CRCerror;
        uartOk = !err && (verified == cw);
        if (!uartOk) {
            // Theo contract motor.h: chiều vật lý không xác định được => caller
            // phải bỏ lệnh chạy. (Hành vi cũ "vẫn phát xung như j3_test" vi phạm
            // contract — jog + có thể chạy thành jog − mà caller không hay biết.)
            Serial.printf("[MOTOR] %s ghi shaft(%d) verify=%d err=%d -> bo lenh, chieu khong xac dinh\n",
                          label, cw ? 1 : 0, verified ? 1 : 0, err);
            return false;
        }
#endif
        dirCW.store(cw, std::memory_order_relaxed);
    }
    return true;
}

void Motor::run(bool cw, uint32_t steps) {
    if (steps == 0) {
        stop();
        return;
    }
    if (stepTimer != nullptr) esp_timer_stop(stepTimer);
    running.store(false, std::memory_order_relaxed);
    preparedRun.store(false, std::memory_order_relaxed);
    coordinatedMode.store(false, std::memory_order_relaxed);

    if (!enabled.load(std::memory_order_relaxed) && !enable(true)) {
        Serial.printf("[MOTOR] %s bo qua run: enable UART that bai\n", label);
        return;
    }
    if (!setDirection(cw)) {
        Serial.printf("[MOTOR] %s bo qua run: khong doi duoc chieu UART\n", label);
        return;
    }

    continuousMode.store(false, std::memory_order_relaxed);
    targetSteps = steps;
    stepsRemaining.store(steps, std::memory_order_relaxed);
    stepCounter.store(0, std::memory_order_relaxed);

    const uint32_t targetInterval = targetSpeedUs.load(std::memory_order_relaxed);
    if (steps < 40) {
        // Chuyển động siêu ngắn: khởi động êm ở tốc độ vừa phải
        accelSteps = steps / 2;
        decelSteps = steps - accelSteps;
        startSpeedUs = (targetInterval > 2500U) ? targetInterval : 2500U;
        currentSpeedUs.store(startSpeedUs, std::memory_order_relaxed);
    } else {
        accelSteps = steps / 4;
        if (accelSteps > 400) accelSteps = 400;
        decelSteps = accelSteps;
        // Bắt đầu từ MAX_STEP_INTERVAL_US (3500us ~ 285 steps/sec) đảm bảo mô-men xoắn khởi động cực đại
        startSpeedUs = (targetInterval > MAX_STEP_INTERVAL_US) ? targetInterval : MAX_STEP_INTERVAL_US;
        currentSpeedUs.store(startSpeedUs, std::memory_order_relaxed);
    }

    running.store(true, std::memory_order_release);
    if (stepTimer != nullptr) {
        const esp_err_t timerErr = esp_timer_start_once(stepTimer, currentSpeedUs.load(std::memory_order_relaxed));
        if (timerErr != ESP_OK) {
            running.store(false, std::memory_order_release);
            stepsRemaining.store(0, std::memory_order_relaxed);
            targetSteps.store(0, std::memory_order_relaxed);
            Serial.printf("[MOTOR LOI] %s esp_timer_start_once that bai: %d\n", label, timerErr);
        }
    } else {
        running.store(false, std::memory_order_release);
        stepsRemaining.store(0, std::memory_order_relaxed);
        targetSteps.store(0, std::memory_order_relaxed);
        Serial.printf("[MOTOR LOI] %s stepTimer null, khong the phat xung!\n", label);
    }
}

void Motor::runContinuous(bool cw) {
    if (stepTimer != nullptr) esp_timer_stop(stepTimer);
    running.store(false, std::memory_order_relaxed);
    preparedRun.store(false, std::memory_order_relaxed);
    coordinatedMode.store(false, std::memory_order_relaxed);

    if (!enabled.load(std::memory_order_relaxed) && !enable(true)) {
        Serial.printf("[MOTOR] %s bo qua runContinuous: enable UART that bai\n", label);
        return;
    }
    if (!setDirection(cw)) {
        Serial.printf("[MOTOR] %s bo qua runContinuous: khong doi duoc chieu UART\n", label);
        return;
    }

    continuousMode.store(true, std::memory_order_relaxed);
    targetSteps = 0xFFFFFFFF;
    stepsRemaining.store(0xFFFFFFFF, std::memory_order_relaxed);
    stepCounter.store(0, std::memory_order_relaxed);
    accelSteps = 120;
    decelSteps = 0;

    startSpeedUs = MAX_STEP_INTERVAL_US; // Bắt đầu từ 400 steps/sec
    currentSpeedUs.store(startSpeedUs, std::memory_order_relaxed);

    running.store(true, std::memory_order_release);
    if (stepTimer != nullptr) {
        const esp_err_t timerErr = esp_timer_start_once(stepTimer, currentSpeedUs.load(std::memory_order_relaxed));
        if (timerErr != ESP_OK) {
            running.store(false, std::memory_order_release);
            stepsRemaining.store(0, std::memory_order_relaxed);
            targetSteps.store(0, std::memory_order_relaxed);
            Serial.printf("[MOTOR LOI] %s esp_timer_start_once that bai: %d\n", label, timerErr);
        }
    } else {
        running.store(false, std::memory_order_release);
        stepsRemaining.store(0, std::memory_order_relaxed);
        targetSteps.store(0, std::memory_order_relaxed);
        Serial.printf("[MOTOR LOI] %s stepTimer null, khong the phat xung!\n", label);
    }
}

bool Motor::prepareCoordinatedRun(bool cw, uint32_t steps, uint32_t intervalUs,
                                  uint32_t rampStartIntervalUs) {
    if (steps == 0 || stepTimer == nullptr) return false;

    esp_timer_stop(stepTimer);
    running.store(false, std::memory_order_release);
    preparedRun.store(false, std::memory_order_relaxed);

    if (!enabled.load(std::memory_order_relaxed)) enable(true);
    if (!enabled.load(std::memory_order_relaxed) || !setDirection(cw)) {
        Serial.printf("[MOTOR] %s khong prepare duoc coordinated run\n", label);
        return false;
    }

    if (intervalUs < MIN_STEP_INTERVAL_US) intervalUs = MIN_STEP_INTERVAL_US;
    continuousMode.store(false, std::memory_order_relaxed);
    coordinatedMode.store(true, std::memory_order_relaxed);
    targetSteps.store(steps, std::memory_order_relaxed);
    stepsRemaining.store(steps, std::memory_order_relaxed);
    stepCounter.store(0, std::memory_order_relaxed);
    // Same ramp fraction and interval ratio on every axis preserve coordination.
    accelSteps = rampStartIntervalUs > intervalUs ? steps / 4 : 0;
    decelSteps = accelSteps;
    startSpeedUs = rampStartIntervalUs > intervalUs ? rampStartIntervalUs : intervalUs;
    targetSpeedUs.store(intervalUs, std::memory_order_relaxed);
    currentSpeedUs.store(startSpeedUs, std::memory_order_relaxed);
    preparedRun.store(true, std::memory_order_release);
    return true;
}

bool Motor::startPreparedRun() {
    if (!preparedRun.exchange(false, std::memory_order_acq_rel) ||
        stepTimer == nullptr || stepsRemaining.load(std::memory_order_relaxed) == 0) {
        return false;
    }

    running.store(true, std::memory_order_release);
    const esp_err_t err = esp_timer_start_once(
        stepTimer, currentSpeedUs.load(std::memory_order_relaxed));
    if (err != ESP_OK) {
        running.store(false, std::memory_order_release);
        stepsRemaining.store(0, std::memory_order_relaxed);
        targetSteps.store(0, std::memory_order_relaxed);
        coordinatedMode.store(false, std::memory_order_relaxed);
        return false;
    }
    return true;
}

void Motor::stop() {
    if (stepTimer != nullptr) esp_timer_stop(stepTimer);
    running.store(false, std::memory_order_release);
    preparedRun.store(false, std::memory_order_release);
    continuousMode.store(false, std::memory_order_relaxed);
    coordinatedMode.store(false, std::memory_order_relaxed);
    stepsRemaining.store(0, std::memory_order_relaxed);
    targetSteps = 0;
    gpio_set_level(static_cast<gpio_num_t>(stepPin), 0);
}

void IRAM_ATTR Motor::stopFromISR() {
    running.store(false, std::memory_order_release);
    preparedRun.store(false, std::memory_order_release);
    continuousMode.store(false, std::memory_order_relaxed);
    coordinatedMode.store(false, std::memory_order_relaxed);
    stepsRemaining.store(0, std::memory_order_relaxed);
    targetSteps = 0;
    if (isHighPin) GPIO.out1_w1tc.val = stepPinMaskHigh;
    else GPIO.out_w1tc = stepPinMaskLow;
}

bool Motor::enable(bool en) {
    if (!en) stop();
    if (!isTMC) {
        enabled.store(en, std::memory_order_release);
        return true;
    }
    if (!takeUart(50)) return false;
    flushUartRx();
    const uint8_t expectedToff = en ? 4 : 0;
    driver->toff(expectedToff);
#if defined(ESP_PLATFORM)
    serialPort->flush();
    delay(2);
    flushUartRx();
    driverVersion = driver->version();
    uartOk = (driverVersion == 0x21) && !driver->CRCerror;
    serialPort->flush();
    delay(2);
    flushUartRx();
    giveUart();
    // Đồng bộ với nhánh host: verify UART fail => báo fail để caller (RELEASE/
    // ENABLE J1-J4, resumeManualRelease) biết driver không đáp ứng thay vì
    // luôn nhận "OK" trong khi mô-men giữ chưa chắc đã đổi.
    if (uartOk) enabled.store(en, std::memory_order_release);
    return uartOk;
#else
    flushUartRx();
    driverVersion = driver->version();
    uartOk = (driverVersion == 0x21) && !driver->CRCerror;
    flushUartRx();
    const bool matched = driver->toff() == expectedToff;
    const bool ok = uartOk && !driver->CRCerror && matched;
    giveUart();
    if (ok) enabled.store(en, std::memory_order_release);
    return ok;
#endif
}

void Motor::setSpeed(uint32_t intervalUs) {
    if (intervalUs < MIN_STEP_INTERVAL_US) intervalUs = MIN_STEP_INTERVAL_US;
    if (intervalUs > MAX_STEP_INTERVAL_US) intervalUs = MAX_STEP_INTERVAL_US;
    targetSpeedUs.store(intervalUs, std::memory_order_relaxed);
    if (!running.load(std::memory_order_relaxed)) {
        currentSpeedUs.store(intervalUs, std::memory_order_relaxed);
    }
}

void Motor::setCurrent(uint16_t mA) {
    currentMa = mA;
    if (!isTMC || !takeUart(50)) return;
    flushUartRx();
    driver->rms_current(currentMa);
#ifdef ARDUINO
    serialPort->flush();
    delay(2);
#endif
    flushUartRx();
    giveUart();
}

void Motor::setHoldCurrentScale(uint8_t iholdVal) {
    holdScale = iholdVal;
    if (!isTMC || !takeUart(50)) return;
    flushUartRx();
    driver->ihold(holdScale);
#ifdef ARDUINO
    serialPort->flush();
    delay(2);
#endif
    flushUartRx();
    giveUart();
}

void Motor::setChopperMode(bool spreadCycle) {
    spreadCycleMode = spreadCycle;
    if (!isTMC || !takeUart(50)) return;
    flushUartRx();
    driver->en_spreadCycle(spreadCycleMode);
    driver->pwm_autoscale(!spreadCycleMode);
    driver->pwm_autograd(!spreadCycleMode);
#ifdef ARDUINO
    serialPort->flush();
    delay(2);
#endif
    flushUartRx();
    giveUart();
}

uint16_t Motor::getSGResult() {
    if (!isTMC || !uartOk || !takeUart(10)) return 1023;
    flushUartRx();
    const uint16_t sg = static_cast<uint16_t>(driver->SG_RESULT());
    giveUart();
    return sg;
}

String Motor::toJson() const {
    char buf[288];
    snprintf(buf, sizeof(buf),
             "{\"running\":%s,\"dir\":\"%s\",\"stepsRemaining\":%u,\"targetSteps\":%u,"
             "\"stepIntervalUs\":%u,\"currentSpeedUs\":%u,\"currentMa\":%u,\"holdScale\":%u,"
             "\"spreadCycle\":%s,\"microsteps\":%u,\"uartOk\":%s,\"version\":%u,\"isTMC\":%s,"
             "\"absSteps\":%lld}",
             running.load(std::memory_order_relaxed) ? "true" : "false",
             dirCW.load(std::memory_order_relaxed) ? "cw" : "ccw",
             stepsRemaining.load(std::memory_order_relaxed),
             targetSteps.load(std::memory_order_relaxed),
             targetSpeedUs.load(std::memory_order_relaxed),
             currentSpeedUs.load(std::memory_order_relaxed),
             currentMa,
             holdScale,
             spreadCycleMode ? "true" : "false",
             microstepsVal,
             uartOk ? "true" : "false",
             driverVersion,
             isTMC ? "true" : "false",
             absSteps.load(std::memory_order_relaxed));
    return String(buf);
}
