#include "homing.h"
#ifdef HOMING_HOST_TEST
#include "homing_fsm_mocks.h"
#else
#include "endstop.h"
#include "joint_model.h"
#include "motor.h"
#include "safety_manager.h"
#endif

#include <algorithm>

namespace {
// Ân hạn khởi động trước khi bật phát hiện stall: TMC2209 trả SG_RESULT=0 lúc chưa
// sinh đủ Back-EMF (lỗi false-trip 30ms đã gặp trên J4).
constexpr uint32_t FAST_CONTACT_GRACE_MS = 600;
constexpr uint32_t SLOW_CONTACT_GRACE_MS = 400;
// Tỷ số measuredSpd/config chấp nhận được (ngoài khoảng -> giữ config)
constexpr float MEASURED_RATIO_MIN = 0.5f;
constexpr float MEASURED_RATIO_MAX = 2.0f;
// Timeout cho các pha quét toàn hành trình (dài hơn timeout khớp thường)
constexpr uint32_t SCAN_TIMEOUT_MS = 60000;
// Home của J3 = endstop MIN + offset (độ)
constexpr float HOME_OFFSET_FROM_MIN_DEG = HOME_BACKOFF_DEG + 0.5f;
// Khoảng nghỉ cho bộ lọc EMA của AS5600 (50Hz, alpha=0.2) ổn định sau khi motor dừng
constexpr uint32_t ENC_SETTLE_MS = 350;
// Deadzone encoder khi đo hướng warmup — dưới ngưỡng coi như encoder không phản hồi.
// Mỗi khớp có gear + đặc tính encoder khác nhau; dùng mảng riêng để tránh
// ngưỡng cứng gây false-fail trên khớp gear nhỏ (J1: 6:1) hoặc EMA chậm.
constexpr float ENC_DIR_DEADZONE_DEG[NUM_MOTORS] = {
    0.30f,  // J1: gear 6:1, encoder 1:1 với khớp → 3° khớp là đủ
    0.30f,  // J2: gear 20:1 — encoder thực ra rất nhạy
    0.30f,  // J3: gear 20:1
    0.30f,  // J4: backoff escape check (>= 0.30° là đã rời cữ)
    0.30f,  // J5: A4988, không homing FSM
    0.30f,  // J6: A4988, không homing FSM
};
// Ngưỡng phát hiện encoder jump bất thường trong WARMUP J4 (tránh ngắt nhầm khi di chuyển góc lớn)
constexpr float HOMING_J4_WARMUP_MAX_DELTA_DEG = 40.0f;
// Deadzone encoder trong WARMUP riêng cho J4: phân biệt giữa độ rơ/đàn hồi cơ khí khi kẹt cữ (~0.53°)
// với chuyển động tự do. Ngưỡng 0.80° đủ lớn hơn đàn hồi kẹt cữ 0.53° nhưng không loại nhầm
// chuyển động thật khi bị rơ/backlash hộp số.
constexpr float HOMING_J4_WARMUP_DEADZONE_DEG = 0.80f;
// Nhịp log tiến trình serial
constexpr uint32_t PROGRESS_LOG_MS = 2000;
// Thời gian settle sau khi motor dừng trong WARMUP trước khi đọc encoder
constexpr uint32_t WARMUP_ENC_SETTLE_MS = 200;
// Số lần tối đa khởi động lại motor trong SCAN_MIN/MAX khi bị nhiễu ISR dừng sớm.
// Mỗi lần khởi động lại bắt buộc motor đã dừng hẳn và không có latch/press thật sự.
constexpr uint8_t MAX_GLITCH_RESTARTS = 3;

} // namespace

HomingController::HomingController() {
    for (uint8_t i = 0; i < NUM_MOTORS; ++i) motors[i] = nullptr;
}

void HomingController::begin(Motor** motors_, Endstops* endstops_, JointModel* joints_) {
    for (uint8_t i = 0; i < NUM_MOTORS; ++i) motors[i] = motors_[i];
    es = endstops_;
    jm = joints_;
}

bool HomingController::startAll() {
    if (active_) return false;
    seqLen_ = 3; // FIX: Chỉ quét homing tuần tự J1, J2, J3 (index 0, 1, 2)
    for (uint8_t i = 0; i < seqLen_; ++i) seq_[i] = i;
    seqIdx_ = 0;
    attempt_ = 0;
    active_ = true;
    lastOk_ = true;
    if (safety_) safety_->assertHoming(true);
    beginScan();
    return true;
}

bool HomingController::startAxis(uint8_t axis) {
    if (active_) return false;
    if (axis >= 4 || motors[axis] == nullptr) return false; // J5/J6: manual only
    seqLen_ = 1;
    seq_[0] = axis;
    seqIdx_ = 0;
    attempt_ = 0;
    active_ = true;
    lastOk_ = true;
    if (safety_) safety_->assertHoming(true);
    beginScan();
    return true;
}

bool HomingController::homeAtMinOffset(uint8_t axis) const noexcept {
    // J3 (2): home = endstop MIN + offset (2.5°). Ra khỏi cữ MIN rồi chốt home ngay tại đó.
    return axis == 2;
}

// ===========================================================================
// SCAN PATH (J1..J4) — quét 2 cữ, 2 tốc độ
// ===========================================================================

void HomingController::beginScan() {
    curAxis_ = seq_[seqIdx_];
    if (jm != nullptr) jm->resetHomingCalibration(curAxis_);
    if (jm != nullptr && curAxis_ == 3) jm->clearHome(curAxis_);
    tmcStallCount_ = 0;
    encStallCount_ = 0;
    lastSgResult_ = 1023;
    minSgResult_ = 1023;
    maxSgResult_ = 0;
    sg1023Consecutive_ = 0;
    warmupProbed_ = false;
    backoffExtend_ = 0;
    secondSide_ = false;
    encDirMult_ = static_cast<float>(AXIS_ENC_SIGN[curAxis_]);
    firstSide_ = EndstopWhich::MIN;
    approachSide_ = EndstopWhich::MIN;
    cwApproach_ = false;
    encFirstRaw_ = 0.0f;
    encSecondRaw_ = 0.0f;
    encCenterRaw_ = 0.0f;
    contactSpan_ = 0;
    measuredSpd_ = JointModel::stepsPerDegree(curAxis_);
    targetEncRaw_ = 0.0f;
    trimCount_ = 0;
    trimStartErr_ = 0.0f;
    trimStartSteps_ = 0;
    settleStartMs_ = 0;
    pendingBackoffSteps_ = 0;
    pendingBackoffCw_ = false;
    phaseStartMs_ = millis();
    lastPollMs_ = millis();
    glitchRestarts_ = 0;
    // Xoá latch cũ không phải press thật (cả MIN và MAX) và bảo đảm enable cả 2 cữ
    for (const auto w : {EndstopWhich::MIN, EndstopWhich::MAX}) {
        if (es != nullptr) {
            es->setPinEnabled(curAxis_, w, true);
            if (es->hasPin(curAxis_, w) && es->isLatched(curAxis_, w) && !es->isPressed(curAxis_, w)) {
                es->clearLatch(curAxis_, w);
            }
        }
    }
    enterWarmup();
}

void HomingController::enterWarmup() {
    Motor& m = *motors[curAxis_];
    if (curAxis_ == 3 && (jm == nullptr || !jm->encOK(curAxis_) ||
                         !std::isfinite(jm->rawEncoder(curAxis_)) || !m.isTmc())) {
        Serial.println("[HOME] J4: encoder/driver khong san sang — HUY");
        finishJoint(false);
        return;
    }
    if (curAxis_ == 3 && !m.testUART()) {
        Serial.println("[HOME] J4: UART preflight FAILED — HUY truoc WARMUP");
        finishJoint(false);
        return;
    }
    // J2 có endstop vật lý: giữ SpreadCycle khi home khớp vai chịu tải.
    // Các TMC còn lại giữ StealthChop; J4 cần chế độ này cho StallGuard4.
    if (m.isTmc()) {
        const uint16_t hc = DEFAULT_AXIS_HOMING_CURRENTS[curAxis_];
        if (hc > 0) m.setCurrent(hc);
        m.setChopperMode(curAxis_ == 1);
        Serial.printf("[HOME] J%u: driver config %u mA, %s, fast=%u us/step\n",
                      curAxis_ + 1, hc, curAxis_ == 1 ? "SpreadCycle" : "StealthChop",
                      DEFAULT_AXIS_HOMING_SPEEDS[curAxis_]);
    }
    m.setSpeed(DEFAULT_AXIS_HOMING_SPEEDS[curAxis_]);
    // Chọn hướng an toàn — tránh BẤT KỲ endstop đang nhấn
    const bool minP = es != nullptr && es->hasPin(curAxis_, EndstopWhich::MIN) &&
                      (es->isPressed(curAxis_, EndstopWhich::MIN) ||
                       es->isLatched(curAxis_, EndstopWhich::MIN));
    const bool maxP = es != nullptr && es->hasPin(curAxis_, EndstopWhich::MAX) &&
                      (es->isPressed(curAxis_, EndstopWhich::MAX) ||
                       es->isLatched(curAxis_, EndstopWhich::MAX));
    // Nhãn MIN/MAX có thể ngược chiều thực tế. Không đoán chiều thoát một cữ
    // đã nhấn trước khi có chuyển động quan sát được trong attempt này.
    if (minP || maxP) {
        if (minP && maxP) {
            Serial.printf("[HOME] J%u: WARMUP ca 2 endstop nhan — ket cuc/chap mach, HUY KHOP\n",
                          curAxis_ + 1);
            finishJoint(false);
            return;
        }
        // Một cữ đang nhấn: thử thoát về phía ngược lại trước khi WARMUP.
        // Dùng WARMUP step chuẩn nhưng đảo chiều so với hướng bình thường.
        // Nếu sau khi thoát cữ vẫn còn nhấn -> HUY (kẹt cơ khí thật).
        const EndstopWhich pressedSide = minP ? EndstopWhich::MIN : EndstopWhich::MAX;
        // Thoát: step CW nếu MIN đang nhấn (giả sử CW ra khỏi MIN), ngược lại CCW.
        // Dùng JointModel::cwForDelta: MIN nhấn → thoát theo hướng tăng góc (+deg), MAX → giảm (-deg).
        const float escapeDeg = minP ? +5.0f : -5.0f;
        const bool escapeCW = JointModel::cwForDelta(curAxis_, escapeDeg);
        const uint32_t escapeSteps = static_cast<uint32_t>(5.0f * JointModel::stepsPerDegree(curAxis_)) + 1;
        if (es != nullptr) {
            es->clearLatch(curAxis_, pressedSide);
            es->setPinEnabled(curAxis_, pressedSide, false); // tắt ngắt phía nhấn khi thoát
        }
        encBefore_ = (jm != nullptr) ? jm->rawEncoder(curAxis_) : 0.0f;
        warmupCW_ = escapeCW;
        warmupSteps_ = escapeSteps;
        m.run(escapeCW, escapeSteps);
        phase_ = HomePhase::WARMUP;
        phaseStartMs_ = millis();
        Serial.printf("[HOME] J%u: WARMUP ESCAPE %s (cw=%d, %u steps) — thoat cu truoc khi WARMUP\n",
                      curAxis_ + 1, minP ? "MIN" : "MAX",
                      static_cast<int>(escapeCW), escapeSteps);
        return;
    }
    // Số bước đủ lớn để encoder đo được (>2–3° góc khớp) — phụ thuộc gear ratio.
    // J4 gear 4:1 dùng 5° (~178 bước) để hành trình vượt hẳn độ rơ hộp số/dây curoa (~1–2°).
    const float targetJointDeg = (curAxis_ == 3) ? 5.0f : 3.0f;
    const float spd = JointModel::stepsPerDegree(curAxis_);
    const uint32_t warmupSteps = static_cast<uint32_t>(targetJointDeg * spd) + 1;

    warmupCW_ = JointModel::cwForDelta(curAxis_, +targetJointDeg);
    // FIX #1: encBefore_ lấy TRƯỚC m.run() — đây là baseline trước khi motor di chuyển.
    // Sau khi motor dừng, chờ thêm WARMUP_ENC_SETTLE_MS (200ms) cho EMA AS5600 ổn định
    // rồi mới đọc encAfter và tính delta. Trước đây delta = encAfter - encBefore_ đọc ngay
    // sau motor dừng (không settle) → EMA chưa hội tụ → delta < deadzone → false-fail.
    encBefore_ = (jm != nullptr) ? jm->rawEncoder(curAxis_) : 0.0f;
    warmupSteps_ = warmupSteps;
    m.run(warmupCW_, warmupSteps);
    phase_ = HomePhase::WARMUP;
    phaseStartMs_ = millis();
    Serial.printf("[HOME] J%u: SAFE_MODE + WARMUP (cw=%d, %u steps, minP=%d, maxP=%d)\n",
                  curAxis_ + 1, static_cast<int>(warmupCW_), warmupSteps,
                  static_cast<int>(minP), static_cast<int>(maxP));
}

void HomingController::enterScanMin() {
    Motor& m = *motors[curAxis_];
    m.setSpeed(DEFAULT_AXIS_HOMING_SPEEDS[curAxis_]);
    // Đảm bảo cả 2 cữ được bật lại (có thể bị tắt trong WARMUP ESCAPE)
    if (es != nullptr) {
        es->setPinEnabled(curAxis_, EndstopWhich::MIN, true);
        es->setPinEnabled(curAxis_, EndstopWhich::MAX, true);
        // Xoá latch cũ trước khi bắt đầu quét liên tục
        es->clearLatch(curAxis_, EndstopWhich::MIN);
        es->clearLatch(curAxis_, EndstopWhich::MAX);
    }
    cwApproach_ = JointModel::cwForDelta(curAxis_, -360.0f);
    firstScanStartSteps_ = m.getAbsoluteSteps();
    tmcStallCount_ = 0;
    resetStallWindow(m);
    m.runContinuous(cwApproach_);
    phase_ = HomePhase::SCAN_MIN;
    phaseStartMs_ = millis();
    lastPollMs_ = millis();
    Serial.printf("[HOME] J%u: SCAN_MIN fast (cw=%d)\n", curAxis_ + 1, static_cast<int>(cwApproach_));
}

void HomingController::enterScanMax() {
    Motor& m = *motors[curAxis_];
    m.setSpeed(DEFAULT_AXIS_HOMING_SPEEDS[curAxis_]);
    const EndstopWhich targetSide = (firstSide_ == EndstopWhich::MIN) ? EndstopWhich::MAX : EndstopWhich::MIN;
    if (es != nullptr) {
        es->clearLatch(curAxis_, EndstopWhich::MIN);
        es->clearLatch(curAxis_, EndstopWhich::MAX);
        es->setPinEnabled(curAxis_, firstSide_, false);
        es->setPinEnabled(curAxis_, targetSide, true);
    }
    backoffExtend_ = 0;
    cwApproach_ = !cwApproach_; // Đảo chiều quét thực tế, kể cả khi cữ đầu mang nhãn MAX.
    firstScanStartSteps_ = m.getAbsoluteSteps();
    tmcStallCount_ = 0;
    resetStallWindow(m);
    m.runContinuous(cwApproach_);
    phase_ = HomePhase::SCAN_MAX;
    phaseStartMs_ = millis();
    lastPollMs_ = millis();
    Serial.printf("[HOME] J%u: SCAN_MAX fast (cw=%d, target=%s)\n",
                  curAxis_ + 1, static_cast<int>(cwApproach_),
                  (targetSide == EndstopWhich::MIN) ? "MIN" : "MAX");
}

void HomingController::enterScanBackoff() {
    Motor& m = *motors[curAxis_];
    m.setSpeed(DEFAULT_AXIS_HOMING_SPEEDS[curAxis_]);
    // Nới rộng mỗi lần lùi lại: 2.5° → 5° → 10° → 20° — đòn bẩy/cam công tắc có hysteresis
    // nhả lớn, lùi đúng 2.5° chưa chắc đã rời vùng actuation. Bậc 4 (20°) đủ cho hầu hết
    // đòn bẩy micro-switch; nếu vẫn nhấn → cơ khí kẹt thật.
    static constexpr float BACKOFF_EXTEND_SCALE[] = {1.0f, 2.0f, 4.0f, 8.0f};
    static_assert(sizeof(BACKOFF_EXTEND_SCALE)/sizeof(BACKOFF_EXTEND_SCALE[0]) > HOMING_BACKOFF_MAX_EXTEND,
                  "BACKOFF_EXTEND_SCALE phai co it nhat HOMING_BACKOFF_MAX_EXTEND+1 phan tu");
    const float scale = BACKOFF_EXTEND_SCALE[backoffExtend_];
    const int64_t steps = JointModel::degreesToSteps(curAxis_, HOME_OFFSET_FROM_MIN_DEG * scale);
    // FIX #3: Xoá latch của endstop approachSide_ trước khi lùi, tránh latch cũ
    // gây false-positive khi kiểm tra "cong tac van nhan" sau backoff.
    if (es != nullptr) {
        es->clearLatch(curAxis_, approachSide_);
        // The switch is still held at the start of backoff. Mask its FALLING ISR so
        // release bounce cannot stop the escape move before the lever opens.
        es->setPinEnabled(curAxis_, approachSide_, false);
    }
    // Non-blocking settle: thay delay(30) bằng BACKOFF_SETTLE_WAIT — motion task không bị block.
    pendingBackoffSteps_ = steps;
    pendingBackoffCw_ = !cwApproach_;
    phase_ = HomePhase::BACKOFF_SETTLE_WAIT;
    settleStartMs_ = millis();
    phaseStartMs_ = settleStartMs_;
    Serial.printf("[HOME] J%u: BACKOFF settle %u ms before %lld steps (cw=%d, lan %u)\n",
                  curAxis_ + 1, HOMING_BACKOFF_SETTLE_MS, static_cast<long long>(steps),
                  static_cast<int>(pendingBackoffCw_), backoffExtend_ + 1);
}

void HomingController::enterScanSlow() {
    Motor& m = *motors[curAxis_];
    m.setSpeed(HOMING_SLOW_SCAN_INTERVAL_US);
    if (es != nullptr) {
        es->clearLatch(curAxis_, EndstopWhich::MIN);
        es->clearLatch(curAxis_, EndstopWhich::MAX);
    }
    tmcStallCount_ = 0;
    resetStallWindow(m);
    m.runContinuous(cwApproach_);
    phase_ = HomePhase::SCAN_SLOW;
    phaseStartMs_ = millis();
    lastPollMs_ = millis();
    Serial.printf("[HOME] J%u: SCAN %s slow (cw=%d, %u us/step)\n",
                  curAxis_ + 1, secondSide_ ? "cữ thứ hai" : "cữ đầu tiên",
                  static_cast<int>(cwApproach_), HOMING_SLOW_SCAN_INTERVAL_US);
}

void HomingController::resetStallWindow(Motor& m) {
    lastStallCheckMs_ = millis();
    lastStallEnc_ = (jm != nullptr && jm->encOK(curAxis_)) ? jm->rawEncoder(curAxis_) : 0.0f;
    lastCheckSteps_ = m.getAbsoluteSteps();
    lastStallSampleSteps_ = lastCheckSteps_;
    lastCheckEnc_ = lastStallEnc_;
    encStallCount_ = 0;
    lastSgPollMs_ = 0;
    lastSgResult_ = 1023;
    minSgResult_ = 1023;
    maxSgResult_ = 0;
    sg1023Consecutive_ = 0;
    tmcStallCount_ = 0;
}

bool HomingController::stallWindowCheck(uint8_t axis, Motor& m, float& encDeltaDeg) {
    encDeltaDeg = 0.0f;
    if (jm == nullptr || !jm->encOK(axis)) return false;
    // Cửa sổ theo bước, scale theo gear ratio: độ dịch lý thuyết của cửa sổ phải vượt
    // ngưỡng encoder đủ xa (>= 2x) để chạy tự do không bị nhầm là stall.
    const int64_t windowSteps = std::max<int64_t>(
        HOMING_STALL_WINDOW_MIN_STEPS,
        JointModel::degreesToSteps(axis, HOMING_STALL_WINDOW_MIN_DEG));
    const int64_t cur = m.getAbsoluteSteps();
    const int64_t stepDelta = llabs(cur - lastStallSampleSteps_);
    if (stepDelta < windowSteps) return encStallCount_ >= STALL_CONSECUTIVE_POLLS;
    lastStallSampleSteps_ = cur;
    const float curEnc = jm->rawEncoder(axis);
    // Pha này chỉ cần biết encoder có di chuyển hay không. Dấu đo từ WARMUP
    // 3° không đủ tin cậy trên J4 có backlash/EMA; dùng nó ở đây biến chuyển
    // động tự do ngược dấu thành delta=0 và tạo contact giả. Dấu được chốt
    // sau sweep hai cữ dài trong enterCenteringScan().
    encDeltaDeg = fabsf(curEnc - lastCheckEnc_);
    if (encDeltaDeg >= HOMING_STALL_ENC_DELTA_DEG) {
        // Rotor đang di chuyển bình thường -> cuộn cửa sổ
        lastCheckSteps_ = cur;
        lastCheckEnc_ = curEnc;
        encStallCount_ = 0;
        return false;
    }
    // Encoder dịch < ngưỡng: tăng biến đếm xác nhận liên tiếp
    if (encStallCount_ < STALL_CONSECUTIVE_POLLS) ++encStallCount_;
    if (encStallCount_ >= STALL_CONSECUTIVE_POLLS) {
        // Stall xác nhận: KHÔNG cuộn mốc — caller bù vị trí chạm
        return true;
    }
    // Giữ mốc đầu nghi stall; sample tiếp theo vẫn phải cách đủ windowSteps.
    return false;
}

int64_t HomingController::compensatedContactStep(const Motor& m, float encDelta) const {
    const int64_t cur = m.getAbsoluteSteps();
    const int64_t delta = JointModel::degreesToSteps(curAxis_, encDelta);
    const int64_t est = lastCheckSteps_ + (cur >= lastCheckSteps_ ? delta : -delta);
    return std::max(std::min(cur, lastCheckSteps_), std::min(std::max(cur, lastCheckSteps_), est));
}

bool HomingController::exceededSecondSideTravel(const Motor& m) const {
    return curAxis_ == 3 && secondSide_ &&
           llabs(m.getAbsoluteSteps()) >= JointModel::degreesToSteps(
               curAxis_, HOMING_J4_MAX_MECHANICAL_SPAN_DEG);
}

bool HomingController::stallGuardConfirmed(Motor& m, uint32_t now) {
    if (!m.isTmc()) return false;
    if (now - lastSgPollMs_ < HOMING_POLL_MS) {
        return tmcStallCount_ >= STALL_CONSECUTIVE_POLLS;
    }

    lastSgPollMs_ = now;
    lastSgResult_ = m.getSGResult();
    if (lastSgResult_ != 1023) {
        sg1023Consecutive_ = 0;
        minSgResult_ = std::min(minSgResult_, lastSgResult_);
        maxSgResult_ = std::max(maxSgResult_, lastSgResult_);
    } else {
        if (sg1023Consecutive_ < 255) ++sg1023Consecutive_;
    }
    if (lastSgResult_ == 1023 || lastSgResult_ > STALL_SG_LEVEL) {
        tmcStallCount_ = 0;
        return false;
    }

    if (tmcStallCount_ < STALL_CONSECUTIVE_POLLS) ++tmcStallCount_;
    return tmcStallCount_ >= STALL_CONSECUTIVE_POLLS;
}

void HomingController::enterCenteringScan() {
    Motor& m = *motors[curAxis_];
    // Centering starts while the second switch is still held. Mask that channel
    // until the arm has moved away so release bounce cannot stop the long move.
    if (es != nullptr && es->hasPin(curAxis_, approachSide_)) {
        es->clearLatch(curAxis_, approachSide_);
        es->setPinEnabled(curAxis_, approachSide_, false);
    }
    // ---- Stage 5: crosscheck — tâm + tỷ số steps/độ thực tế từ góc tích lũy unwrapped ----
    encCenterRaw_ = (encFirstRaw_ + encSecondRaw_) / 2.0f;
    float spanRaw = fabsf(encSecondRaw_ - encFirstRaw_);
    if (curAxis_ == 3 && spanRaw >= HOMING_MIN_ENC_SPAN_DEG[curAxis_]) {
        const float sweepJointSign = static_cast<float>(AXIS_STEP_SIGN[curAxis_]) *
                                     (m.getAbsoluteSteps() >= 0 ? 1.0f : -1.0f);
        encDirMult_ = ((encSecondRaw_ - encFirstRaw_) * sweepJointSign >= 0.0f) ? 1.0f : -1.0f;
    }

    const bool hasEndstop = es != nullptr && (es->hasPin(curAxis_, EndstopWhich::MIN) ||
                                              es->hasPin(curAxis_, EndstopWhich::MAX));

    // Integrity check:
    // Với trục không endstop (J4): kiểm tra contactSpan_ cơ khí phải đạt sàn
    // commissioning để chặn kẹt cữ ảo nhưng không loại nhầm hành trình thực tế.
    const int64_t minMechanicalSpanSteps =
        JointModel::degreesToSteps(curAxis_, HOMING_MIN_MECHANICAL_SPAN_DEG);
    if (!hasEndstop && contactSpan_ < minMechanicalSpanSteps) {
        Serial.printf("[HOME] J%u: CROSSCHECK contactSpan %lld < %lld steps (%.1f deg) — ket cu ao, HUY KHOP\n",
                      curAxis_ + 1, static_cast<long long>(contactSpan_),
                      static_cast<long long>(minMechanicalSpanSteps),
                      HOMING_MIN_MECHANICAL_SPAN_DEG);
        finishJoint(false);
        return;
    }

    const float cfgSpd = (static_cast<float>(DEFAULT_FULL_STEPS) *
                          static_cast<float>(DEFAULT_MICROSTEPS) *
                          DEFAULT_AXIS_GEAR_RATIOS[curAxis_]) / 360.0f;
    float measuredSpd = cfgSpd;
    float ratio = 1.0f;
    if (!hasEndstop && spanRaw < HOMING_MIN_ENC_SPAN_DEG[curAxis_]) {
        Serial.printf("[HOME] J%u: CROSSCHECK encoder span %.2f < %.2f deg — HUY KHOP\n",
                      curAxis_ + 1, spanRaw, HOMING_MIN_ENC_SPAN_DEG[curAxis_]);
        finishJoint(false);
        return;
    }
    if (spanRaw >= HOMING_MIN_ENC_SPAN_DEG[curAxis_]) {
        measuredSpd = static_cast<float>(contactSpan_) / spanRaw;
        ratio = (cfgSpd > 0.0f) ? (measuredSpd / cfgSpd) : 1.0f;
        if (!hasEndstop && (ratio < 0.05f || ratio > 20.0f)) {
            Serial.printf("[HOME] J%u: CROSSCHECK encoder ratio %.2f ngoai [0.05,20.0] — HUY KHOP\n",
                          curAxis_ + 1, ratio);
            finishJoint(false);
            return;
        }
        if (ratio < MEASURED_RATIO_MIN || ratio > MEASURED_RATIO_MAX) {
            measuredSpd = cfgSpd;
            Serial.printf("[HOME] J%u: measured ratio %.2f ngoai [%g,%g] -> giu config\n",
                          curAxis_ + 1, ratio, MEASURED_RATIO_MIN, MEASURED_RATIO_MAX);
        }
    } else {
        measuredSpd = cfgSpd;
    }
    measuredSpd_ = measuredSpd;
    if (jm != nullptr && curAxis_ != 3) jm->applyHomingCalibration(curAxis_, encDirMult_, measuredSpd);
    Serial.printf("[HOME] J%u: CROSSCHECK enc_c=%.1f span=%lld spd=%.2f (x%.2f)\n",
                      curAxis_ + 1, encCenterRaw_, static_cast<long long>(contactSpan_),
                      measuredSpd, ratio);

    // ---- Chạy về home bằng bước tương đối (rotor đi tự do -> chính xác từng bước);
    //      VERIFY sẽ đối chiếu encoder độc lập và trim nếu steps/deg đo được còn lệch. ----
    // J1/J2/J4 về tâm; J3 về MIN+offset sau khi đã đo đủ hai cữ.
    int64_t stepsBack = contactSpan_ / 2;
    if (homeAtMinOffset(curAxis_)) {
        const int64_t offsetSteps = JointModel::degreesToSteps(curAxis_, HOME_OFFSET_FROM_MIN_DEG);
        if (offsetSteps <= 0 || contactSpan_ <= offsetSteps) {
            Serial.printf("[HOME] J3: span khong du cho MIN+offset — HUY KHOP\n");
            finishJoint(false);
            return;
        }
        stepsBack = (firstSide_ == EndstopWhich::MIN) ? contactSpan_ - offsetSteps : offsetSteps;
    }
    if (stepsBack < 0) stepsBack = 0;
    const bool cwBack = !cwApproach_; // quay về phía cữ chạm đầu tiên
    centeringTargetSteps_ = m.getAbsoluteSteps() + (cwBack ? stepsBack : -stepsBack);
    m.setSpeed(DEFAULT_AXIS_HOMING_SPEEDS[curAxis_]);
    if (stepsBack > 0) m.run(cwBack, static_cast<uint32_t>(stepsBack));
    phase_ = HomePhase::CENTERING;
    phaseStartMs_ = millis();
    settleStartMs_ = phaseStartMs_;
    Serial.printf("[HOME] J%u: CENTERING %lld steps (cw=%d, enc_center=%.1f)\n",
                  curAxis_ + 1, static_cast<long long>(stepsBack),
                  static_cast<int>(cwBack), encCenterRaw_);
}

void HomingController::enterVerify() {
    if (jm == nullptr) { finishJoint(true); return; }

    if (!jm->encOK(curAxis_)) {
        Serial.printf("[HOME] J%u: VERIFY encoder mat ket noi — HUY KHOP\n", curAxis_ + 1);
        finishJoint(false);
        return;
    }

    const float raw = jm->rawEncoder(curAxis_);
    const bool hasEndstop = (es != nullptr) && (es->hasPin(curAxis_, EndstopWhich::MIN) ||
                                                es->hasPin(curAxis_, EndstopWhich::MAX));

    if (hasEndstop) {
        Serial.printf("[HOME] J%u: VERIFY OK (co endstop — %s, enc_zero=%.1f)\n",
                      curAxis_ + 1,
                      homeAtMinOffset(curAxis_) ? "chot home tai MIN+offset" : "chot home tai tam co khi",
                      raw);
    } else {
        targetEncRaw_ = encCenterRaw_;
        phase_ = HomePhase::VERIFY;
        phaseStartMs_ = millis();
        settleStartMs_ = phaseStartMs_ - ENC_SETTLE_MS;
        return;
    }
    finishJoint(true);
}

void HomingController::tickScan(uint32_t now, Motor& m) {
    switch (phase_) {
        case HomePhase::WARMUP: {
            if (now - phaseStartMs_ > HOMING_JOINT_TIMEOUT_MS) { m.stop(); finishJoint(false); return; }
            if (m.isRunning()) return; // chờ motor hoàn tất
            const bool minStill = es != nullptr && es->hasPin(curAxis_, EndstopWhich::MIN) &&
                                  es->isPressed(curAxis_, EndstopWhich::MIN);
            const bool maxStill = es != nullptr && es->hasPin(curAxis_, EndstopWhich::MAX) &&
                                  es->isPressed(curAxis_, EndstopWhich::MAX);
            if (minStill || maxStill) {
                if (minStill && maxStill) {
                    Serial.printf("[HOME] J%u: WARMUP ca 2 endstop nhan — ket cuc/chap mach, HUY KHOP\n",
                                  curAxis_ + 1);
                    finishJoint(false);
                    return;
                }
                Serial.printf("[HOME] J%u: WARMUP CONTACT (%s) — backoff nguoc chieu vua chay\n",
                              curAxis_ + 1, minStill ? "MIN" : "MAX");
                m.stop();
                approachSide_ = minStill ? EndstopWhich::MIN : EndstopWhich::MAX;
                cwApproach_ = warmupCW_;
                firstScanStartSteps_ = m.getAbsoluteSteps(); // B1: init scan origin cho J4 travel guard
                enterScanBackoff();
                return;
            }
            // Motor đã dừng, công tắc đã nhả — chuyển sang settle wait non-blocking
            phase_ = HomePhase::WARMUP_SETTLE_WAIT;
            settleStartMs_ = now;
            phaseStartMs_ = now;
            return;
        }
        case HomePhase::WARMUP_SETTLE_WAIT: {
            if (now - phaseStartMs_ > HOMING_JOINT_TIMEOUT_MS) { m.stop(); finishJoint(false); return; }
            if (now - settleStartMs_ < WARMUP_ENC_SETTLE_MS) return;
            // Kiểm tra dịch chuyển encoder sau khi motor phát bước warmup (~3°).
            const float encAfter = (jm != nullptr) ? jm->rawEncoder(curAxis_) : 0.0f;
            const float delta = encAfter - encBefore_;
            if (curAxis_ == 3) {
                const float commandedDeg = static_cast<float>(warmupSteps_) / JointModel::stepsPerDegree(curAxis_);
                if (!std::isfinite(delta) || fabsf(delta) > HOMING_J4_WARMUP_MAX_DELTA_DEG) {
                    Serial.printf("[HOME] J4: WARMUP encoder jump (before=%.2f after=%.2f delta=%.2f expected=%.2f max=%.2f) — HUY\n",
                                  encBefore_, encAfter, delta, commandedDeg, HOMING_J4_WARMUP_MAX_DELTA_DEG);
                    finishJoint(false);
                    return;
                }
            }
            const float warmupDeadzone = (curAxis_ == 3) ? HOMING_J4_WARMUP_DEADZONE_DEG : ENC_DIR_DEADZONE_DEG[curAxis_];
            if (fabsf(delta) < warmupDeadzone) {
                if (curAxis_ == 3) {
                    if (!warmupProbed_) {
                        warmupProbed_ = true;
                        warmupCW_ = !warmupCW_;
                        encBefore_ = encAfter;
                        m.run(warmupCW_, warmupSteps_);
                        phase_ = HomePhase::WARMUP;
                        phaseStartMs_ = now;
                        Serial.printf("[HOME] J4: WARMUP khong dich (delta=%.2f < %.2f, enc=%.2f) — probe nguoc mot lan\n",
                                      delta, warmupDeadzone, encAfter);
                        return;
                    }
                    if (jm != nullptr && jm->encOK(curAxis_)) {
                        encDirMult_ = static_cast<float>(AXIS_ENC_SIGN[curAxis_]);
                        Serial.printf("[HOME] J4: WARMUP ca 2 chieu delta=%.2f < %.2f — fallback config encSign=%+.0f, tiep tuc scan\n",
                                      delta, warmupDeadzone, encDirMult_);
                        enterScanMin();
                        return;
                    }
                    Serial.printf("[HOME] J4: WARMUP encoder khong phan hoi ca hai chieu (delta=%.2f < %.2f) — HUY\n",
                                  delta, warmupDeadzone);
                    finishJoint(false);
                    return;
                }
                if (jm != nullptr && jm->encOK(curAxis_)) {
                    encDirMult_ = static_cast<float>(AXIS_ENC_SIGN[curAxis_]);
                    Serial.printf("[HOME] J%u: WARMUP encoder delta=%.2f < %.2f — fallback config encSign=%+.0f, tiep tuc scan\n",
                                  curAxis_ + 1, delta, warmupDeadzone, encDirMult_);
                    enterScanMin();
                    return;
                }
                Serial.printf("[HOME] J%u: WARMUP encoder mat ket noi (I2C loi) — HUY KHOP\n", curAxis_ + 1);
                finishJoint(false);
                return;
            }
            const float intendedJointSign = static_cast<float>(AXIS_STEP_SIGN[curAxis_]) *
                                             (warmupCW_ ? 1.0f : -1.0f);
            encDirMult_ = (delta * intendedJointSign >= 0.0f) ? 1.0f : -1.0f;
            Serial.printf("[HOME] J%u: WARMUP encDirMult=%+.0f (delta=%.2f, intent=%.0f, probe=%d)\n",
                          curAxis_ + 1, encDirMult_, delta, intendedJointSign,
                          static_cast<int>(warmupProbed_));
            enterScanMin();
            return;
        }
        case HomePhase::SCAN_MIN:
        case HomePhase::SCAN_MAX: {
            const bool firstLeg = (phase_ == HomePhase::SCAN_MIN);
            if (curAxis_ == 3 && firstLeg && llabs(m.getAbsoluteSteps() - firstScanStartSteps_) >=
                JointModel::degreesToSteps(curAxis_, HOMING_J4_MAX_MECHANICAL_SPAN_DEG)) {
                Serial.println("[HOME] J4: SCAN_MIN vuot gioi han hanh trinh — HUY");
                finishJoint(false);
                return;
            }
            const EndstopWhich targetSide = firstLeg
                ? EndstopWhich::MIN
                : ((firstSide_ == EndstopWhich::MIN) ? EndstopWhich::MAX : EndstopWhich::MIN);
            if (now - phaseStartMs_ > SCAN_TIMEOUT_MS) {
                m.stop();
                Serial.printf("[HOME] J%u: SCAN_%s TIMEOUT — khong cham cu trong %us\n",
                              curAxis_ + 1, firstLeg ? "MIN" : "MAX", SCAN_TIMEOUT_MS / 1000);
                finishJoint(false); return;
            }
            if (now - lastPollMs_ > PROGRESS_LOG_MS) {
                lastPollMs_ = now;
                Serial.printf("[HOME] J%u: SCAN_%s progress step=%.1f enc=%.1f MIN=%d MAX=%d en=%d/%d\n",
                              curAxis_ + 1, firstLeg ? "MIN" : "MAX",
                              jm ? jm->angleFromSteps(curAxis_) : 0.0f,
                              jm ? jm->rawEncoder(curAxis_) : 0.0f,
                              es ? es->isPhysicallyPressed(curAxis_, EndstopWhich::MIN) : 0,
                              es ? es->isPhysicallyPressed(curAxis_, EndstopWhich::MAX) : 0,
                              es ? es->isPinEnabled(curAxis_, EndstopWhich::MIN) : 0,
                              es ? es->isPinEnabled(curAxis_, EndstopWhich::MAX) : 0);
            }

            // Bảo vệ leg 2: StallGuard/step-lag chỉ bật sau khi đã rời cữ đầu đủ xa (> 10°)
            const int64_t curSteps = m.getAbsoluteSteps();
            bool movedFarEnough = true;
            if (!firstLeg) {
                const float minSpanDeg = 10.0f; // 10° là đủ để rời khỏi cữ chạm đầu tiên
                const int64_t leg2Steps = llabs(curSteps - firstScanStartSteps_);
                movedFarEnough = leg2Steps >= JointModel::degreesToSteps(curAxis_, minSpanDeg);
                if (!movedFarEnough) {
                    resetStallWindow(m);
                }
            }

            // 1. Endstop vật lý (cữ có bật ngắt enable)
            EndstopWhich hit = targetSide;
            bool hitAny = false;
            bool glitchCleared = false; // ISR dừng motor nhưng chân không còn nhấn khi poll
            if (es != nullptr) {
                for (const auto w : {EndstopWhich::MIN, EndstopWhich::MAX}) {
                    if (!es->hasPin(curAxis_, w) || !es->isPinEnabled(curAxis_, w)) continue;

                    // Chỉ công tắc ĐANG BỊ ĐÈ THẬT SỰ (isPressed) hoặc đã được SafetyManager xác nhận (isLatched)
                    // mới được coi là tiếp xúc cơ khí. Tuyệt đối không nhận diện cữ nếu chân đang không nhấn (glitch)!
                    const bool pressed = es->isPressed(curAxis_, w);
                    const bool latched = es->isLatched(curAxis_, w);

                    if (pressed || latched) {
                        if (!firstLeg && w != targetSide) {
                            // Xung trên cữ đối diện khi đang chạy ra xa là xung nhiễu cảm ứng từ dây stepper;
                            // xoá latch và bỏ qua để không làm gián đoạn hành trình về targetSide.
                            es->clearLatch(curAxis_, w);
                            continue;
                        }
                        hit = w;
                        hitAny = true;
                        break;
                    } else if (es->isrPending(curAxis_, w)) {
                        // isrPending = true nhưng chân hiện tại không nhấn -> xung nhiễu thoáng qua, xoá cờ!
                        es->clearLatch(curAxis_, w);
                        glitchCleared = true;
                    }
                }
            }

            const bool hasEndstop = (es != nullptr) && (es->hasPin(curAxis_, EndstopWhich::MIN) ||
                                                        es->hasPin(curAxis_, EndstopWhich::MAX));

            if (!hasEndstop && exceededSecondSideTravel(m)) {
                m.stop();
                Serial.printf("[HOME] J4: SCAN_MAX vuot %.1f deg khong co cu thu 2 — HUY KHOP\n",
                              HOMING_J4_MAX_MECHANICAL_SPAN_DEG);
                finishJoint(false);
                return;
            }

            float encDelta = 0.0f;
            const bool sensorlessReady = !hasEndstop && movedFarEnough &&
                                         (now - phaseStartMs_ > FAST_CONTACT_GRACE_MS);
            const bool encoderStalled = sensorlessReady && stallWindowCheck(curAxis_, m, encDelta);
            const bool sgStalled = sensorlessReady && stallGuardConfirmed(m, now);
            // SENSORLESS stall detection (J4):
            // Nhận diện chạm khi encoder step-lag phát hiện motor dừng quay (kẹt cơ khí)
            // HOẶC StallGuard xác nhận tải cơ khí cao ở tốc độ nhanh.
            if (!hitAny && sensorlessReady && (encoderStalled || (sgStalled && lastSgResult_ <= STALL_SG_LEVEL))) {
                m.stop();
                m.setAbsoluteSteps(compensatedContactStep(m, encDelta));
                hitAny = true;
                Serial.printf("[HOME] J%u: SCAN_%s SENSORLESS stall (sg=%u <= %u, range=%u..%u, encDelta=%.2f < %.2f deg, sgStall=%d encStall=%d)\n",
                              curAxis_ + 1, firstLeg ? "MIN" : "MAX",
                              lastSgResult_, STALL_SG_LEVEL,
                              minSgResult_, maxSgResult_,
                              encDelta, HOMING_STALL_ENC_DELTA_DEG,
                              static_cast<int>(sgStalled), static_cast<int>(encoderStalled));
            }

            // 4. Motor dừng sớm mà không có contact nào
            if (!hitAny && !m.isRunning() && (now - phaseStartMs_ > 500)) {
                m.stop();
                // glitchCleared=true: ISR dừng motor do nhiễu rồi thoáng nhả → không có tiếp xúc thật.
                // Khởi động lại motor thay vì hủy khớp (giới hạn MAX_GLITCH_RESTARTS lần).
                if (glitchCleared && glitchRestarts_ < MAX_GLITCH_RESTARTS) {
                    ++glitchRestarts_;
                    Serial.printf("[HOME] J%u: SCAN_%s glitch stop #%u — khoi dong lai motor (khong co press/pending)\n",
                                  curAxis_ + 1, firstLeg ? "MIN" : "MAX", glitchRestarts_);
                    resetStallWindow(m);
                    m.setSpeed(DEFAULT_AXIS_HOMING_SPEEDS[curAxis_]);
                    if (es != nullptr) {
                        es->clearLatch(curAxis_, EndstopWhich::MIN);
                        es->clearLatch(curAxis_, EndstopWhich::MAX);
                    }
                    m.runContinuous(cwApproach_);
                    return;
                }
                Serial.printf("[HOME] J%u: SCAN_%s motor stopped early (hitAny=%d, isrP_MIN=%d isrP_MAX=%d p_MIN=%d p_MAX=%d en_MIN=%d en_MAX=%d, glitch=%u)\n",
                              curAxis_ + 1, firstLeg ? "MIN" : "MAX",
                              static_cast<int>(hitAny),
                              es ? es->isrPending(curAxis_, EndstopWhich::MIN) : 0,
                              es ? es->isrPending(curAxis_, EndstopWhich::MAX) : 0,
                              es ? es->isPressed(curAxis_, EndstopWhich::MIN) : 0,
                              es ? es->isPressed(curAxis_, EndstopWhich::MAX) : 0,
                              es ? es->isPinEnabled(curAxis_, EndstopWhich::MIN) : 0,
                              es ? es->isPinEnabled(curAxis_, EndstopWhich::MAX) : 0,
                              glitchRestarts_);
                finishJoint(false); return;
            }

            if (hitAny) {
                m.stop();
                if (es != nullptr && es->hasPin(curAxis_, hit)) {
                    es->consumeLatch(curAxis_, hit); // consume ngay, tránh latch cũ gây chạm ảo ở pha SLOW
                }
                approachSide_ = hit;
                Serial.printf("[HOME] J%u: SCAN_%s CONTACT (%s)\n",
                              curAxis_ + 1, firstLeg ? "MIN" : "MAX",
                              (hit == EndstopWhich::MIN) ? "MIN" : "MAX");
                enterScanBackoff();
            }
            return;
        }
        case HomePhase::BACKOFF_SETTLE_WAIT: {
            if (now - phaseStartMs_ > HOMING_JOINT_TIMEOUT_MS) { m.stop(); finishJoint(false); return; }
            if (now - settleStartMs_ < HOMING_BACKOFF_SETTLE_MS) return;
            // Settle done — start backoff move non-blocking
            backoffStartEnc_ = (jm != nullptr && jm->encOK(curAxis_)) ? jm->rawEncoder(curAxis_) : 0.0f;
            Motor& m2 = *motors[curAxis_];
            // absSteps của Motor luôn tăng khi CW và giảm khi CCW
            backoffTargetSteps_ = m2.getAbsoluteSteps() + (pendingBackoffCw_ ? pendingBackoffSteps_ : -pendingBackoffSteps_);
            if (pendingBackoffSteps_ > 0) {
                m2.run(pendingBackoffCw_, static_cast<uint32_t>(pendingBackoffSteps_));
            }
            settleStartMs_ = now;
            phase_ = HomePhase::SCAN_BACKOFF;
            phaseStartMs_ = now;
            Serial.printf("[HOME] J%u: BACKOFF %lld steps (cw=%d, lan %u)\n",
                          curAxis_ + 1, static_cast<long long>(pendingBackoffSteps_),
                          static_cast<int>(pendingBackoffCw_), backoffExtend_ + 1);
            return;
        }
        case HomePhase::SCAN_BACKOFF: {
            if (now - phaseStartMs_ > HOMING_JOINT_TIMEOUT_MS) { m.stop(); finishJoint(false); return; }
            if (m.isRunning()) { settleStartMs_ = now; return; }
            if (curAxis_ == 3 && jm != nullptr) {
                if (now - settleStartMs_ < ENC_SETTLE_MS) return;
                const float moved = fabsf(jm->rawEncoder(curAxis_) - backoffStartEnc_);
                if (m.getAbsoluteSteps() != backoffTargetSteps_) {
                    Serial.printf("[HOME] J4: BACKOFF khong thoat hard-stop — HUY (step=%lld target=%lld, encBefore=%.2f encAfter=%.2f movedAbs=%.2f min=%.2f cw=%d)\n",
                                  static_cast<long long>(m.getAbsoluteSteps()), static_cast<long long>(backoffTargetSteps_),
                                  backoffStartEnc_, jm->rawEncoder(curAxis_), moved, ENC_DIR_DEADZONE_DEG[curAxis_],
                                  static_cast<int>(pendingBackoffCw_));
                    finishJoint(false);
                    return;
                }
                if (moved < ENC_DIR_DEADZONE_DEG[curAxis_]) {
                    if (backoffExtend_ < HOMING_BACKOFF_MAX_EXTEND) {
                        ++backoffExtend_;
                        Serial.printf("[HOME] J4: BACKOFF encoder chua dich (%.2f deg) — noi rong lan %u\n",
                                      moved, backoffExtend_ + 1);
                        enterScanBackoff();
                        return;
                    }
                    Serial.printf("[HOME] J4: BACKOFF encoder khong dich sau %u lan — HUY\n",
                                  backoffExtend_ + 1);
                    finishJoint(false);
                    return;
                }
            }
            // Lùi xong mà cữ vẫn bị đè: chưa chắc kẹt cơ khí — có thể hysteresis nhả của
            // công tắc lớn hơn khoảng lùi. Nới rộng (2.5°→5°→10°→20°) trước khi kết luận fail.
            // FIX #3: Latch đã được xoá trong enterScanBackoff() — chỉ kiểm tra isPressed()
            // (trạng thái thật), không để latch cũ gây false-positive "jammed".
            if (es != nullptr && es->hasPin(curAxis_, approachSide_) &&
                es->isPhysicallyPressed(curAxis_, approachSide_)) {
                // Log encoder delta để chẩn đoán: motor thực sự di chuyển (long-travel switch)
                // hay encoder không dịch (motor stall — cần báo cho owner kiểm tra cơ khí).
                if (jm != nullptr && jm->encOK(curAxis_)) {
                    const float encNow = jm->rawEncoder(curAxis_);
                    const float encMoved = fabsf(encNow - backoffStartEnc_);
                    Serial.printf("[HOME] J%u: BACKOFF cong tac van nhan (enc_moved=%.2f deg)%s\n",
                                  curAxis_ + 1, encMoved,
                                  (encMoved < 0.3f) ? " — CANH BAO: motor co the bi ket co hoc!" : "");
                } else {
                    Serial.printf("[HOME] J%u: BACKOFF cong tac van nhan\n", curAxis_ + 1);
                }
                if (backoffExtend_ < HOMING_BACKOFF_MAX_EXTEND) {
                    ++backoffExtend_;
                    Serial.printf("[HOME] J%u: BACKOFF noi rong lan %u\n",
                                  curAxis_ + 1, backoffExtend_ + 1);
                    enterScanBackoff();
                    return;
                }
                Serial.printf("[HOME] J%u: BACKOFF jammed sau %u lan noi rong — ket cuc, HUY KHOP\n",
                              curAxis_ + 1, backoffExtend_ + 1);
                finishJoint(false);
                return;
            }
            if (es != nullptr && es->hasPin(curAxis_, approachSide_)) {
                es->setPinEnabled(curAxis_, approachSide_, true);
                es->clearLatch(curAxis_, approachSide_);
            }
            enterScanSlow();
            return;
        }
        case HomePhase::SCAN_SLOW: {
            if (now - phaseStartMs_ > HOMING_JOINT_TIMEOUT_MS) { m.stop(); finishJoint(false); return; }
            if (curAxis_ == 3 && !secondSide_ && llabs(m.getAbsoluteSteps() - firstScanStartSteps_) >=
                JointModel::degreesToSteps(curAxis_, HOMING_J4_MAX_MECHANICAL_SPAN_DEG)) {
                Serial.println("[HOME] J4: SLOW cu dau vuot gioi han hanh trinh — HUY");
                finishJoint(false);
                return;
            }
            const EndstopWhich otherSide = approachSide_ == EndstopWhich::MIN
                ? EndstopWhich::MAX : EndstopWhich::MIN;
            if (es != nullptr && es->hasPin(curAxis_, otherSide)) {
                // Đang bò chậm vào approachSide_ (chỉ cách 2.5°); cữ đối diện cách xa 90-180°.
                // Bất kỳ tín hiệu nào trên otherSide đều là nhiễu cảm ứng, luôn xoá latch.
                es->clearLatch(curAxis_, otherSide);
            }
            if (now - lastPollMs_ > PROGRESS_LOG_MS) {
                lastPollMs_ = now;
                Serial.printf("[HOME] J%u: SCAN_SLOW progress step=%.1f enc=%.1f\n",
                              curAxis_ + 1,
                              jm ? jm->angleFromSteps(curAxis_) : 0.0f,
                              jm ? jm->rawEncoder(curAxis_) : 0.0f);
            }

            // 1. Endstop của cữ đang dò (J1..J3) — nguồn chính xác nhất
            bool hitEndstop = false;
            if (es != nullptr && es->hasPin(curAxis_, approachSide_) && es->isPinEnabled(curAxis_, approachSide_)) {
                const bool pressed = es->isPressed(curAxis_, approachSide_);
                const bool latched = es->isLatched(curAxis_, approachSide_);
                if (pressed || latched) {
                    hitEndstop = true;
                } else if (es->isrPending(curAxis_, approachSide_)) {
                    es->clearLatch(curAxis_, approachSide_);
                }
            }

            const bool hasEndstop = (es != nullptr) && (es->hasPin(curAxis_, EndstopWhich::MIN) ||
                                                        es->hasPin(curAxis_, EndstopWhich::MAX));

            if (!hasEndstop && exceededSecondSideTravel(m)) {
                m.stop();
                Serial.printf("[HOME] J4: SCAN_SLOW vuot %.1f deg khong co cu thu 2 — HUY KHOP\n",
                              HOMING_J4_MAX_MECHANICAL_SPAN_DEG);
                finishJoint(false);
                return;
            }

            float encDelta = 0.0f;
            bool hitStall = false;
            const bool sensorlessReady = !hasEndstop && (now - phaseStartMs_ > SLOW_CONTACT_GRACE_MS);
            const bool encoderStalled = sensorlessReady && stallWindowCheck(curAxis_, m, encDelta);
            // Ở tốc độ chậm (1800 µs/step ~10 RPM), Back-EMF của động cơ quá yếu để StallGuard4 nhận diện chính xác.
            // Bộ mã hóa góc AS5600 qua kiểm tra trễ bước (stallWindowCheck) là nguồn sự thật duy nhất xác nhận tiếp xúc cơ học.
            if (!hitEndstop && sensorlessReady && encoderStalled) {
                hitStall = true;
                Serial.printf("[HOME] J%u: SLOW SENSORLESS stall (encoder step-lag, encDelta=%.2f < %.2f deg, sg=%u)\n",
                              curAxis_ + 1, encDelta, HOMING_STALL_ENC_DELTA_DEG, lastSgResult_);
            }

            // 3. Motor dừng sớm không rõ lý do
            if (!hitEndstop && !hitStall && !m.isRunning() && (now - phaseStartMs_ > 500)) {
                Serial.printf("[HOME] J%u: SCAN_SLOW motor stopped early\n", curAxis_ + 1);
                finishJoint(false);
                return;
            }
            if (!hitEndstop && !hitStall) return;

            m.stop();
            const int64_t cur = m.getAbsoluteSteps();
            // Endstop latch: vị trí dừng = điểm chạm (ISR dừng gần tức thì).
            // Stall: bù độ trễ cửa sổ — rotor còn chạy tự do một đoạn encDelta trong
            // cửa sổ trước khi kẹt, điểm chạm thực ≈ mốc cửa sổ + encDelta quy đổi bước.
            int64_t contactStep = cur;
            if (hitStall) {
                contactStep = compensatedContactStep(m, encDelta);
                m.setAbsoluteSteps(contactStep); // bỏ bước mất khi rotor đã kẹt
                Serial.printf("[HOME] J%u: SLOW stall (encDelta=%.2f, cur=%lld, contact=%lld)\n",
                              curAxis_ + 1, encDelta, static_cast<long long>(cur),
                              static_cast<long long>(contactStep));
            }
            if (hitEndstop && es != nullptr) es->consumeLatch(curAxis_, approachSide_);

            if (homeAtMinOffset(curAxis_) && approachSide_ == EndstopWhich::MIN && !secondSide_) {
                // Chỉ chốt Home ngay nếu cữ chạm đầu tiên thực sự là cữ MIN.
                // Nếu ban đầu J3 đang đè cữ MAX (approachSide_ == MAX), nó sẽ đi tiếp xuống nhánh
                // !secondSide_ bên dưới để lùi ra và quét về cữ MIN rồi mới chốt Home ở enterCenteringScan().
                encFirstRaw_ = (jm != nullptr) ? jm->rawEncoder(curAxis_) : 0.0f;
                firstSide_ = approachSide_;
                m.setAbsoluteSteps(0);
                const int64_t offsetSteps = JointModel::degreesToSteps(curAxis_, HOME_OFFSET_FROM_MIN_DEG);
                const bool cwBack = !cwApproach_;
                centeringTargetSteps_ = m.getAbsoluteSteps() + (cwBack ? offsetSteps : -offsetSteps);
                if (es != nullptr && es->hasPin(curAxis_, approachSide_)) {
                    es->clearLatch(curAxis_, approachSide_);
                    es->setPinEnabled(curAxis_, approachSide_, false);
                }
                m.setSpeed(DEFAULT_AXIS_HOMING_SPEEDS[curAxis_]);
                if (offsetSteps > 0) m.run(cwBack, static_cast<uint32_t>(offsetSteps));
                phase_ = HomePhase::CENTERING;
                phaseStartMs_ = now;
                settleStartMs_ = now;
                Serial.printf("[HOME] J%u: MIN SLOW CONTACT (enc=%.1f) -> ra khoi cu %lld steps (cw=%d) roi chot HOME\n",
                              curAxis_ + 1, encFirstRaw_, static_cast<long long>(offsetSteps), static_cast<int>(cwBack));
                return;
            }

            if (!secondSide_) {
                // Cữ ĐẦU TIÊN — gốc bước mới tại điểm chạm đã bù (J1..J4).
                encFirstRaw_ = (jm != nullptr) ? jm->rawEncoder(curAxis_) : 0.0f;
                firstSide_ = approachSide_;
                secondSide_ = true;
                m.setAbsoluteSteps(0); // contact #1 = gốc bước tương đối; span cữ 1→2 = |absSteps tại cữ 2|
                Serial.printf("[HOME] J%u: SLOW CONTACT #1 (%s, enc=%.1f, contact=%lld)\n",
                              curAxis_ + 1, (approachSide_ == EndstopWhich::MIN) ? "MIN" : "MAX",
                              encFirstRaw_, static_cast<long long>(contactStep));

                // Lùi an toàn khỏi cữ 1 (5.0° cho trục có endstop, 14.0° cho J4 sensorless) trước khi bắt đầu quét cữ 2.
                // Vô hiệu hóa ngắt cữ 1 để tránh dội tiếp điểm / rung lắc khi motor đảo chiều làm dừng sớm.
                const float backoffDeg = (curAxis_ == 3) ? 14.0f : 5.0f;
                const int64_t backoffSteps = JointModel::degreesToSteps(curAxis_, backoffDeg);
                const bool cwBack = !cwApproach_;
                backoffStartEnc_ = encFirstRaw_;
                pendingBackoffCw_ = cwBack;
                backoffTargetSteps_ = m.getAbsoluteSteps() + (cwBack ? backoffSteps : -backoffSteps);
                if (es != nullptr) {
                    es->clearLatch(curAxis_, firstSide_);
                    es->setPinEnabled(curAxis_, firstSide_, false);
                }
                m.setSpeed(DEFAULT_AXIS_HOMING_SPEEDS[curAxis_]);
                if (backoffSteps > 0) m.run(cwBack, static_cast<uint32_t>(backoffSteps));
                phase_ = HomePhase::LEG1_BACKOFF;
                phaseStartMs_ = now;
                settleStartMs_ = now;
                Serial.printf("[HOME] J%u: LEG1 BACKOFF %lld steps (cw=%d) de roi khoi cu %s\n",
                              curAxis_ + 1, static_cast<long long>(backoffSteps),
                              static_cast<int>(cwBack), (firstSide_ == EndstopWhich::MIN) ? "MIN" : "MAX");
                return;
            } else {
                // Cữ THỨ HAI — đóng gói quét (J1..J4).
                encSecondRaw_ = (jm != nullptr) ? jm->rawEncoder(curAxis_) : 0.0f;
                contactSpan_ = llabs(contactStep);
                Serial.printf("[HOME] J%u: SLOW CONTACT #2 (%s, enc=%.1f, span=%lld)\n",
                              curAxis_ + 1, (approachSide_ == EndstopWhich::MIN) ? "MIN" : "MAX",
                              encSecondRaw_, static_cast<long long>(contactSpan_));
                enterCenteringScan();
            }
            return;
        }
        case HomePhase::LEG1_BACKOFF: {
            if (now - phaseStartMs_ > HOMING_JOINT_TIMEOUT_MS) { m.stop(); finishJoint(false); return; }
            if (m.isRunning()) {
                settleStartMs_ = now;
                return;
            }
            if (now - settleStartMs_ < HOMING_BACKOFF_SETTLE_MS) return;
            if (curAxis_ == 3 && jm != nullptr) {
                if (now - settleStartMs_ < ENC_SETTLE_MS) return;
                const float moved = fabsf(jm->rawEncoder(curAxis_) - backoffStartEnc_);
                const float minMoved = (curAxis_ == 3) ? 0.10f : ENC_DIR_DEADZONE_DEG[curAxis_];
                if (m.getAbsoluteSteps() != backoffTargetSteps_ || moved < minMoved) {
                    Serial.printf("[HOME] J4: LEG1 BACKOFF khong thoat hard-stop — HUY (step=%lld target=%lld, encBefore=%.2f encAfter=%.2f movedAbs=%.2f min=%.2f cw=%d)\n",
                                  static_cast<long long>(m.getAbsoluteSteps()), static_cast<long long>(backoffTargetSteps_),
                                  backoffStartEnc_, jm->rawEncoder(curAxis_), moved, minMoved,
                                  static_cast<int>(pendingBackoffCw_));
                    finishJoint(false);
                    return;
                }
            }

            if (es != nullptr) {
                if (es->isPhysicallyPressed(curAxis_, firstSide_)) {
                    m.stop();
                    Serial.printf("[HOME] J%u: LEG1 BACKOFF chua roi cu — HUY, khong quet tiep voi cu bi mask\n", curAxis_ + 1);
                    finishJoint(false);
                    return;
                }
                es->setPinEnabled(curAxis_, firstSide_, true);
                es->clearLatch(curAxis_, firstSide_);
                es->consumeLatch(curAxis_, firstSide_);
            }
            enterScanMax();
            return;
        }
        case HomePhase::CENTERING: {
            if (now - phaseStartMs_ > HOMING_JOINT_TIMEOUT_MS) { m.stop(); finishJoint(false); return; }
            if (m.isRunning()) {
                settleStartMs_ = now;
                return;
            }
            if (m.getAbsoluteSteps() != centeringTargetSteps_) {
                Serial.printf("[HOME] J%u: CENTERING dung som — HUY, khong luu Home\n", curAxis_ + 1);
                finishJoint(false);
                return;
            }
            if (es != nullptr && es->hasPin(curAxis_, approachSide_)) {
                if (es->isPhysicallyPressed(curAxis_, approachSide_)) {
                    Serial.printf("[HOME] J%u: CENTERING xong nhung cu van nhan — HUY\n", curAxis_ + 1);
                    finishJoint(false);
                    return;
                }
                es->setPinEnabled(curAxis_, approachSide_, true);
                es->clearLatch(curAxis_, approachSide_);
            }
            // Motor stopped — chuyển sang settle wait non-blocking trước khi VERIFY
            phase_ = HomePhase::VERIFY_SETTLE_WAIT;
            settleStartMs_ = now;
            // phaseStartMs_ giữ nguyên để timeout tổng thể không reset quá sớm; settleStartMs_ dùng cho 350ms
            return;
        }
        case HomePhase::VERIFY_SETTLE_WAIT: {
            if (now - phaseStartMs_ > HOMING_JOINT_TIMEOUT_MS) { m.stop(); finishJoint(false); return; }
            if (now - settleStartMs_ < ENC_SETTLE_MS) return;
            enterVerify();
            return;
        }
        case HomePhase::VERIFY: {
            if (now - phaseStartMs_ > HOMING_JOINT_TIMEOUT_MS) { m.stop(); finishJoint(false); return; }
            if (jm == nullptr || !jm->encOK(curAxis_)) {
                // Encoder mất giữa chừng: verify bất khả thi và drift-watchdog sẽ false-FAULT
                // với encoder chết → không chấp nhận home theo bước mù.
                Serial.printf("[HOME] J%u: VERIFY encoder mat ket noi — HUY KHOP\n", curAxis_ + 1);
                finishJoint(false);
                return;
            }
            if (m.isRunning()) {
                settleStartMs_ = now;
                return;
            }
            if (now - settleStartMs_ < ENC_SETTLE_MS) return;
            const float raw = jm->rawEncoder(curAxis_);
            const float spanRaw = fabsf(encSecondRaw_ - encFirstRaw_);
            const float tol = HOMING_VERIFY_TOL_BASE_DEG +
                              HOMING_VERIFY_TOL_SPAN_PCT * 0.01f * (spanRaw / 2.0f);
            const float err = targetEncRaw_ - raw;
            if (fabsf(err) <= tol) {
                Serial.printf("[HOME] J%u: VERIFY OK (enc=%.1f, err=%.2f, tol=%.2f)\n",
                              curAxis_ + 1, raw, err, tol);
                finishJoint(true);
                return;
            }
            // FIX: Kiểm tra phân kỳ (err tăng sau trim) hoặc vượt giới hạn hành trình trim
            if (trimCount_ > 0) {
                const int64_t trimMovedSteps = llabs(m.getAbsoluteSteps() - trimStartSteps_);
                const int64_t maxTrimSteps = JointModel::degreesToSteps(curAxis_, HOMING_TRIM_MAX_TRAVEL_DEG);
                if (fabsf(err) > trimStartErr_ + 1.0f || trimMovedSteps > maxTrimSteps) {
                    Serial.printf("[HOME] J%u: VERIFY TRIM diverge/overtravel (err=%.2f prev=%.2f steps=%lld) — HUY\n",
                                  curAxis_ + 1, err, trimStartErr_, static_cast<long long>(trimMovedSteps));
                    finishJoint(false);
                    return;
                }
            }
            if (trimCount_ >= 2) {
                Serial.printf("[HOME] J%u: VERIFY FAIL (err=%.2f > tol=%.2f, %u lan trim)\n",
                              curAxis_ + 1, err, tol, trimCount_);
                finishJoint(false); // -> retry quét lại từ đầu
                return;
            }
            // Trim: chạy bước hữu hạn (discrete steps) về phía target theo encoder (tránh overshoot do trễ mẫu I2C)
            ++trimCount_;
            const float encSign = curAxis_ == 3 ? encDirMult_ : jm->encSignOf(curAxis_);
            const bool cw = JointModel::cwForDelta(curAxis_, err / encSign);
            const float moveDeg = std::min(fabsf(err), 10.0f);
            const uint32_t trimSteps = static_cast<uint32_t>(lroundf(moveDeg * measuredSpd_));
            trimStartErr_ = fabsf(err);
            trimStartSteps_ = m.getAbsoluteSteps();
            m.setSpeed(HOMING_SLOW_SCAN_INTERVAL_US);
            if (trimSteps > 0) {
                m.run(cw, trimSteps);
            }
            settleStartMs_ = now;
            Serial.printf("[HOME] J%u: TRIM #%u (err=%.2f, cw=%d, steps=%u)\n",
                          curAxis_ + 1, trimCount_, err, static_cast<int>(cw), trimSteps);
            return;
        }
        default:
            break;
    }
}

// ===========================================================================
// CHUNG
// ===========================================================================

void HomingController::tick() {
    if (!active_) return;
    if (curAxis_ >= NUM_MOTORS || motors[curAxis_] == nullptr) {
        active_ = false;
        return;
    }
    Motor& m = *motors[curAxis_];
    const uint32_t now = millis();
    if (curAxis_ == 3 && (jm == nullptr || !jm->encOK(curAxis_) || !std::isfinite(jm->rawEncoder(curAxis_)))) {
        Serial.println("[HOME] J4: encoder mat/khong hop le — HUY");
        finishJoint(false);
        return;
    }
    tickScan(now, m);
}

void HomingController::finishJoint(bool ok) {
    // Every failure path (including sensorless cross-check rejection) must leave
    // the axis positively stopped.  Most callers already stop on contact, but
    // making this idempotent prevents a stale pulse from keeping ArmController
    // busy and blocking the next HOME_AXIS command.
    if (curAxis_ < NUM_MOTORS && motors[curAxis_] != nullptr) motors[curAxis_]->stop();
    // Clear pending backoff state so stale steps don't survive retry/cancel
    pendingBackoffSteps_ = 0;
    pendingBackoffCw_ = false;
    restoreDriverDefaults(curAxis_);
    if (ok && jm != nullptr) {
        if (curAxis_ == 3) jm->applyHomingCalibration(curAxis_, encDirMult_, measuredSpd_);
        jm->setHomeHere(curAxis_);
    } else if (jm != nullptr) {
        (void)jm->resyncFromEncoder(curAxis_);
    }
    if (es != nullptr) {
        es->clearLatch(curAxis_, EndstopWhich::MIN);
        es->clearLatch(curAxis_, EndstopWhich::MAX);
        es->setPinEnabled(curAxis_, EndstopWhich::MIN, true);
        es->setPinEnabled(curAxis_, EndstopWhich::MAX, true);
    }
    Serial.printf("[HOME] J%u: %s\n", curAxis_ + 1, ok ? "SETREF OK" : "FAILED");

    if (!ok) {
        retryOrFail();
        return;
    }
    ++seqIdx_;
    attempt_ = 0;
    if (seqIdx_ < seqLen_) {
        beginScan();
    } else {
        active_ = false;
        if (es != nullptr) {
            es->clearAllLatches();
        }
        if (safety_) safety_->assertHoming(false);
        lastOk_ = true;
        phase_ = HomePhase::IDLE;
        Serial.println("[HOME] Toan bo hoan tat");
    }
}

void HomingController::retryOrFail() {
    if (attempt_ + 1 < HOMING_MAX_ATTEMPTS) {
        ++attempt_;
        Serial.printf("[HOME] J%u: FAILED — thu lai lan %u/%u\n",
                      curAxis_ + 1, attempt_ + 1, HOMING_MAX_ATTEMPTS);
        beginScan(); // quét lại từ đầu (SAFE_MODE/WARMUP tự áp dụng lại)
        return;
    }
    active_ = false;
    if (safety_) safety_->assertHoming(false);
    lastOk_ = false;
    phase_ = HomePhase::IDLE;
    Serial.printf("[HOME] J%u: FAILED sau %u lan thu — huy chuoi homing\n",
                  curAxis_ + 1, HOMING_MAX_ATTEMPTS);
}

void HomingController::restoreDriverDefaults(uint8_t axis) {
    if (axis >= NUM_MOTORS || motors[axis] == nullptr) return;
    Motor& m = *motors[axis];
    if (m.isTmc()) {
        // H2/F3 FIX: khôi phục đúng dòng chạy từng khớp (không phải 800mA chung cho tất cả)
        // và chế độ chopper đúng: J2 dùng SpreadCycle (chịu tải), các trục khác StealthChop.
        const uint16_t runCurrent = DEFAULT_AXIS_RUN_CURRENTS[axis];
        if (runCurrent > 0) m.setCurrent(runCurrent);
        m.setChopperMode(axis == 1); // J2: SpreadCycle (true); J1/J3/J4: StealthChop (false)
        if (axis == 3) {
            m.setHoldCurrentScale(WRIST_J4_HOLD_SCALE); // Khóa cứng J4
        }
    }
    m.setSpeed(DEFAULT_STEP_INTERVAL_US);
}

void HomingController::cancel() {
    if (!active_) return;
    if (curAxis_ < NUM_MOTORS && motors[curAxis_] != nullptr) motors[curAxis_]->stop();
    restoreDriverDefaults(curAxis_);

    if (jm != nullptr) (void)jm->resyncFromEncoder(curAxis_);
    if (es != nullptr) {
        for (uint8_t a = 0; a < NUM_MOTORS; ++a) {
            es->clearLatch(a, EndstopWhich::MIN);
            es->clearLatch(a, EndstopWhich::MAX);
            es->setPinEnabled(a, EndstopWhich::MIN, true);
            es->setPinEnabled(a, EndstopWhich::MAX, true);
        }
    }
    // Clear pending backoff state to avoid stale on next start
    pendingBackoffSteps_ = 0;
    pendingBackoffCw_ = false;
    settleStartMs_ = 0;
    active_ = false;
    if (safety_) safety_->assertHoming(false);
    lastOk_ = false;
    phase_ = HomePhase::IDLE;
    Serial.println("[HOME] Huy boi nguoi dung");
}

String HomingController::toJson() const {
    static const char* PHASE_NAMES[] = {
        "idle", "warmup", "warmup_settle_wait", "scan_min", "scan_backoff",
        "backoff_settle_wait", "scan_slow", "scan_max", "leg1_backoff", "centering", "verify",
        "verify_settle_wait", "done"
    };
    static_assert(sizeof(PHASE_NAMES) / sizeof(PHASE_NAMES[0]) ==
                      static_cast<uint8_t>(HomePhase::DONE) + 1,
                  "PHASE_NAMES phai khop voi HomePhase");
    char buf[128];
    snprintf(buf, sizeof(buf),
             "{\"active\":%s,\"lastOk\":%s,\"axis\":%u,\"phase\":\"%s\"}",
             active_.load(std::memory_order_relaxed) ? "true" : "false",
             lastOk_.load(std::memory_order_relaxed) ? "true" : "false",
             active_.load(std::memory_order_relaxed) ? (curAxis_.load(std::memory_order_relaxed) + 1) : 0,
             PHASE_NAMES[static_cast<uint8_t>(phase_.load(std::memory_order_relaxed))]);
    return String(buf);
}
